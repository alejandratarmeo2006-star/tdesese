# LDS Service Mission Tracker — Android build

**Important:** the original file named `lds-service-mission-tracker.apk` was not an APK. It was a ZIP archive containing the app source code (there was no Android manifest or compiled `classes.dex`). This project adds a Capacitor Android wrapper and a GitHub Actions workflow to build a real debug APK.

## Easiest route (no Android SDK on your computer)
1. Extract this project ZIP.
2. Upload the extracted project to a new GitHub repository.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build Android APK** and press **Run workflow** (or push the project to `main`/`master`).
5. When it finishes, open the workflow run, scroll to **Artifacts**, and download `lds-service-mission-tracker-debug-apk`.
6. Extract the downloaded artifact; it contains `app-debug.apk`. Transfer it to your Samsung phone and tap it to install. If Android asks, allow your browser or Files app to install unknown apps for this one installation.

## Notes
- The APK is a debug build, suitable for installing on your own phone; it is not a Play Store release.
- App records are stored locally in the browser/WebView database. Keep using the app on the same installation and export backups in Settings if that option is available. Uninstalling the app or clearing its storage may erase local records.
- The workflow installs dependencies from npm and therefore requires GitHub Actions to have internet access.
