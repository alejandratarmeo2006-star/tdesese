import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.service.missiontracker',
  appName: 'LDS Service Mission Tracker',
  webDir: 'dist',
  android: { allowMixedContent: false },
};

export default config;
