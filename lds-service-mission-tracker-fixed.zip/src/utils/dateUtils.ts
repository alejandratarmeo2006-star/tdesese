/**
 * Accurate device-local calendar date and time utilities.
 *
 * CRITICAL:
 * - Uses the device's actual JavaScript local calendar and system clock.
 * - Never uses UTC conversions or new Date().toISOString().slice(0, 10).
 * - Avoids timezone boundary and Daylight Saving Time drift by constructing local dates.
 * - Monday is the start of the reporting week; Sunday is the end.
 */

/**
 * Format a Date object into a local 'YYYY-MM-DD' calendar string.
 */
export function formatToLocalDateString(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Parse a 'YYYY-MM-DD' string into a local Date object set to 12:00:00 (midday).
 * Setting midday prevents any DST shift from rolling the date backwards or forwards.
 */
export function parseLocalDate(dateStr: string): Date {
  const parts = dateStr.split('-');
  if (parts.length !== 3) {
    const fallback = new Date();
    return new Date(fallback.getFullYear(), fallback.getMonth(), fallback.getDate(), 12, 0, 0);
  }
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  return new Date(year, month, day, 12, 0, 0);
}

/**
 * Get the Monday (start of reporting week) for any given Date.
 * Handles month/year boundaries, leap years, and daylight-saving transitions cleanly.
 */
export function getMondayOfWeek(date: Date): Date {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0);
  // In JavaScript: Sunday is 0, Monday is 1, Tuesday is 2, ..., Saturday is 6
  // (day + 6) % 7 yields: Monday = 0, Tuesday = 1, ..., Sunday = 6
  const dayOfWeek = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - dayOfWeek);
  return d;
}

/**
 * Get the Sunday (end of reporting week) for a given Monday date.
 */
export function getSundayOfWeek(mondayDate: Date): Date {
  const d = new Date(mondayDate.getFullYear(), mondayDate.getMonth(), mondayDate.getDate(), 12, 0, 0);
  d.setDate(d.getDate() + 6);
  return d;
}

/**
 * Return the Monday YYYY-MM-DD reporting-week key for any given date string or Date object.
 */
export function getWeekStartDateStr(dateInput: string | Date): string {
  const date = typeof dateInput === 'string' ? parseLocalDate(dateInput) : dateInput;
  const monday = getMondayOfWeek(date);
  return formatToLocalDateString(monday);
}

/**
 * Return the Sunday YYYY-MM-DD for a given Monday string.
 */
export function getWeekEndDateStr(mondayStr: string): string {
  const monday = parseLocalDate(mondayStr);
  const sunday = getSundayOfWeek(monday);
  return formatToLocalDateString(sunday);
}

/**
 * Check if a date string is today in the local device calendar.
 */
export function isTodayLocal(dateStr: string): boolean {
  return dateStr === formatToLocalDateString(new Date());
}

/**
 * Check if today is Sunday in the local device calendar.
 */
export function isTodaySunday(): boolean {
  return new Date().getDay() === 0;
}

/**
 * Format a Date or date string to full human date:
 * e.g., "Thursday, October 22, 2026"
 */
export function formatFullDate(dateInput: Date | string): string {
  const date = typeof dateInput === 'string' ? parseLocalDate(dateInput) : dateInput;
  return date.toLocaleDateString(undefined, {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

/**
 * Format a reporting-week range nicely:
 * e.g., "Oct 19 – Oct 25, 2026" or "Dec 28, 2026 – Jan 3, 2027"
 */
export function formatWeekDateRange(mondayStr: string, sundayStr?: string): string {
  const monday = parseLocalDate(mondayStr);
  const sunday = sundayStr ? parseLocalDate(sundayStr) : getSundayOfWeek(monday);

  const sameYear = monday.getFullYear() === sunday.getFullYear();
  const sameMonth = sameYear && monday.getMonth() === sunday.getMonth();

  const monMonth = monday.toLocaleDateString(undefined, { month: 'short' });
  const sunMonth = sunday.toLocaleDateString(undefined, { month: 'short' });

  if (sameMonth) {
    return `${monMonth} ${monday.getDate()} – ${sunday.getDate()}, ${monday.getFullYear()}`;
  } else if (sameYear) {
    return `${monMonth} ${monday.getDate()} – ${sunMonth} ${sunday.getDate()}, ${monday.getFullYear()}`;
  } else {
    return `${monMonth} ${monday.getDate()}, ${monday.getFullYear()} – ${sunMonth} ${sunday.getDate()}, ${sunday.getFullYear()}`;
  }
}

/**
 * Format minutes into friendly hours and minutes:
 * e.g. 150 -> "2h 30m"
 * 60 -> "1h 00m"
 * 45 -> "45m"
 * 0 -> "0m"
 */
export function formatMinutes(totalMinutes: number): string {
  if (!totalMinutes || totalMinutes <= 0) return '0m';
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;

  if (hours === 0) {
    return `${mins}m`;
  }
  if (mins === 0) {
    return `${hours}h`;
  }
  return `${hours}h ${String(mins).padStart(2, '0')}m`;
}

/**
 * Convert minutes to decimal hours rounded to 2 decimal places:
 * e.g., 150 minutes -> 2.5
 */
export function minutesToDecimalHours(minutes: number): number {
  if (!minutes || minutes <= 0) return 0;
  return Math.round((minutes / 60) * 100) / 100;
}

/**
 * Get the 7 days (Monday through Sunday) for a given week.
 */
export function getDaysOfWeek(mondayStr: string): Array<{
  date: string;
  dayName: string;
  fullDayName: string;
  dayNumber: number;
  isToday: boolean;
  isFuture: boolean;
}> {
  const monday = parseLocalDate(mondayStr);
  const todayStr = formatToLocalDateString(new Date());
  const today = parseLocalDate(todayStr);

  const days: Array<{
    date: string;
    dayName: string;
    fullDayName: string;
    dayNumber: number;
    isToday: boolean;
    isFuture: boolean;
  }> = [];

  for (let i = 0; i < 7; i++) {
    const current = new Date(monday.getFullYear(), monday.getMonth(), monday.getDate() + i, 12, 0, 0);
    const dateStr = formatToLocalDateString(current);
    days.push({
      date: dateStr,
      dayName: current.toLocaleDateString(undefined, { weekday: 'short' }),
      fullDayName: current.toLocaleDateString(undefined, { weekday: 'long' }),
      dayNumber: current.getDate(),
      isToday: dateStr === todayStr,
      isFuture: current.getTime() > today.getTime(),
    });
  }

  return days;
}

/**
 * Get current device timezone string for Settings display.
 */
export function getDeviceTimeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local System Time';
  } catch {
    return 'Local System Time';
  }
}
