export interface ServiceSession {
  id: string;
  date: string; // 'YYYY-MM-DD' in local calendar
  durationMinutes: number; // positive integer minutes
  createdAt: string; // timestamp for recordkeeping
  weekStartDate: string; // Monday 'YYYY-MM-DD'
}

export interface WeeklyReport {
  id: string; // e.g., 'report_2026-10-19'
  weekStartDate: string; // Monday 'YYYY-MM-DD' (Primary unique key)
  weekEndDate: string; // Sunday 'YYYY-MM-DD'
  gospelStudyDays: number | null; // 0-7 days
  companionMinisteringCount: number | null; // nonnegative integer
  journalingCount: number | null; // nonnegative integer
  calculatedHours: number; // calculated from sessions in that week
  reportedHours: number; // final value for submission
  isHoursManuallyOverridden: boolean;
  manualHours: number | null;
  isSubmitted: boolean;
  submittedAt: string | null; // ISO timestamp when confirmed
  lastUpdatedAt: string;
}

export interface AppSettings {
  weeklyGoalHours: number; // default 40
  installedAt: string;
}

export interface DayOverview {
  date: string; // 'YYYY-MM-DD'
  dayName: string; // 'Mon', 'Tue', etc.
  fullDayName: string; // 'Monday', etc.
  dayNumber: number; // 1-31
  isToday: boolean;
  isFuture: boolean;
  totalMinutes: number;
  sessionCount: number;
}

export interface WeekSummary {
  weekStartDate: string; // Monday 'YYYY-MM-DD'
  weekEndDate: string; // Sunday 'YYYY-MM-DD'
  formattedDateRange: string;
  isCurrentWeek: boolean;
  totalMinutes: number;
  totalHoursDecimal: number;
  sessionCount: number;
  goalHours: number;
  progressPercent: number;
  report: WeeklyReport | null;
  reportStatus: 'not_started' | 'in_progress' | 'pending_submission' | 'submitted';
}

export const OFFICIAL_FORMS_URL =
  'https://forms.cloud.microsoft/pages/responsepage.aspx?id=s-7mYddfqkquPGHo3rCbeSJpXQqt91pIhuHlnPEKQMVUMlE0RE9HNUJXNzNDOUE4OTM3Rjg5WllLUi4u&origin=QRCode&route=shorturl';

export const DEFAULT_WEEKLY_GOAL_HOURS = 40;
