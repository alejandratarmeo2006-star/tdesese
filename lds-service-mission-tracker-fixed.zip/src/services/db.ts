import { AppSettings, DEFAULT_WEEKLY_GOAL_HOURS, ServiceSession, WeeklyReport } from '../types';
import { formatToLocalDateString, getWeekStartDateStr } from '../utils/dateUtils';

const DB_NAME = 'lds_service_tracker_db';
const DB_VERSION = 1;

const STORES = {
  SESSIONS: 'sessions',
  REPORTS: 'reports',
  SETTINGS: 'settings',
} as const;

let dbPromise: Promise<IDBDatabase> | null = null;

export function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not supported on this device.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // 1. Sessions store
      if (!db.objectStoreNames.contains(STORES.SESSIONS)) {
        const sessionStore = db.createObjectStore(STORES.SESSIONS, { keyPath: 'id' });
        sessionStore.createIndex('date', 'date', { unique: false });
        sessionStore.createIndex('weekStartDate', 'weekStartDate', { unique: false });
      }

      // 2. Reports store (Keyed uniquely by weekStartDate Monday)
      if (!db.objectStoreNames.contains(STORES.REPORTS)) {
        db.createObjectStore(STORES.REPORTS, { keyPath: 'weekStartDate' });
      }

      // 3. Settings store
      if (!db.objectStoreNames.contains(STORES.SETTINGS)) {
        db.createObjectStore(STORES.SETTINGS, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      dbPromise = null;
      reject(request.error || new Error('Failed to open database'));
    };
  });

  return dbPromise;
}

// ----------------- Service Sessions -----------------

export async function getAllSessions(): Promise<ServiceSession[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.SESSIONS, 'readonly');
    const store = tx.objectStore(STORES.SESSIONS);
    const request = store.getAll();

    request.onsuccess = () => {
      const results = (request.result || []) as ServiceSession[];
      // Sort in descending order by date, then createdAt
      results.sort((a, b) => {
        if (a.date !== b.date) return b.date.localeCompare(a.date);
        return (b.createdAt || '').localeCompare(a.createdAt || '');
      });
      resolve(results);
    };

    request.onerror = () => reject(request.error || new Error('Failed to load service sessions'));
  });
}

export async function saveSession(session: ServiceSession): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.SESSIONS, 'readwrite');
    const store = tx.objectStore(STORES.SESSIONS);

    // Ensure weekStartDate is accurately set
    const accurateWeekStart = getWeekStartDateStr(session.date);
    const sessionToSave: ServiceSession = {
      ...session,
      weekStartDate: accurateWeekStart,
    };

    const request = store.put(sessionToSave);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error || new Error('Failed to save service session'));
  });
}

export async function deleteSession(sessionId: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.SESSIONS, 'readwrite');
    const store = tx.objectStore(STORES.SESSIONS);
    const request = store.delete(sessionId);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error || new Error('Failed to delete service session'));
  });
}

// ----------------- Weekly Reports -----------------

export async function getAllReports(): Promise<WeeklyReport[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.REPORTS, 'readonly');
    const store = tx.objectStore(STORES.REPORTS);
    const request = store.getAll();

    request.onsuccess = () => {
      const results = (request.result || []) as WeeklyReport[];
      // Sort reverse chronological by weekStartDate
      results.sort((a, b) => b.weekStartDate.localeCompare(a.weekStartDate));
      resolve(results);
    };

    request.onerror = () => reject(request.error || new Error('Failed to load weekly reports'));
  });
}

export async function getReportForWeek(weekStartDate: string): Promise<WeeklyReport | null> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.REPORTS, 'readonly');
    const store = tx.objectStore(STORES.REPORTS);
    const request = store.get(weekStartDate);

    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error(`Failed to load report for week ${weekStartDate}`));
  });
}

export async function saveReport(report: WeeklyReport): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.REPORTS, 'readwrite');
    const store = tx.objectStore(STORES.REPORTS);
    const request = store.put(report);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error || new Error('Failed to save weekly report'));
  });
}

// ----------------- App Settings -----------------

export async function getAppSettings(): Promise<AppSettings> {
  const defaultSettings: AppSettings = {
    weeklyGoalHours: DEFAULT_WEEKLY_GOAL_HOURS,
    installedAt: formatToLocalDateString(new Date()),
  };

  try {
    const db = await openDatabase();
    return new Promise((resolve) => {
      const tx = db.transaction(STORES.SETTINGS, 'readonly');
      const store = tx.objectStore(STORES.SETTINGS);
      const request = store.get('main_settings');

      request.onsuccess = () => {
        if (request.result && request.result.value) {
          resolve({
            ...defaultSettings,
            ...request.result.value,
          });
        } else {
          resolve(defaultSettings);
        }
      };

      request.onerror = () => resolve(defaultSettings);
    });
  } catch {
    return defaultSettings;
  }
}

export async function saveAppSettings(settings: Partial<AppSettings>): Promise<void> {
  const current = await getAppSettings();
  const updated: AppSettings = {
    ...current,
    ...settings,
  };

  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORES.SETTINGS, 'readwrite');
    const store = tx.objectStore(STORES.SETTINGS);
    const request = store.put({ key: 'main_settings', value: updated });

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error || new Error('Failed to save app settings'));
  });
}

// ----------------- Backup / Export & Restore -----------------

export async function exportAllData(): Promise<string> {
  const [sessions, reports, settings] = await Promise.all([
    getAllSessions(),
    getAllReports(),
    getAppSettings(),
  ]);

  const payload = {
    version: 1,
    exportedAt: new Date().toISOString(),
    settings,
    sessions,
    reports,
  };

  return JSON.stringify(payload, null, 2);
}

export async function importAllData(jsonStr: string): Promise<{ sessionCount: number; reportCount: number }> {
  const parsed = JSON.parse(jsonStr);
  if (!parsed || !Array.isArray(parsed.sessions)) {
    throw new Error('Invalid backup file format: missing sessions array.');
  }

  const db = await openDatabase();

  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORES.SESSIONS, STORES.REPORTS, STORES.SETTINGS], 'readwrite');
    const sessionStore = tx.objectStore(STORES.SESSIONS);
    const reportStore = tx.objectStore(STORES.REPORTS);
    const settingsStore = tx.objectStore(STORES.SETTINGS);

    // Save sessions
    for (const session of parsed.sessions) {
      if (session.id && session.date && typeof session.durationMinutes === 'number') {
        sessionStore.put({
          ...session,
          weekStartDate: getWeekStartDateStr(session.date),
        });
      }
    }

    // Save reports if present
    if (Array.isArray(parsed.reports)) {
      for (const report of parsed.reports) {
        if (report.weekStartDate) {
          reportStore.put(report);
        }
      }
    }

    // Save settings if present
    if (parsed.settings) {
      settingsStore.put({ key: 'main_settings', value: parsed.settings });
    }

    tx.oncomplete = () => {
      resolve({
        sessionCount: parsed.sessions.length,
        reportCount: Array.isArray(parsed.reports) ? parsed.reports.length : 0,
      });
    };

    tx.onerror = () => reject(tx.error || new Error('Failed to import backup data'));
  });
}
