import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { AppSettings, DEFAULT_WEEKLY_GOAL_HOURS, ServiceSession, WeeklyReport, WeekSummary } from '../types';
import {
  formatToLocalDateString,
  formatWeekDateRange,
  getSundayOfWeek,
  getWeekEndDateStr,
  getWeekStartDateStr,
  isTodaySunday,
  minutesToDecimalHours,
  parseLocalDate,
} from '../utils/dateUtils';
import * as db from '../services/db';

interface MissionContextValue {
  sessions: ServiceSession[];
  reports: WeeklyReport[];
  settings: AppSettings;
  todayDateStr: string;
  currentWeekStartDate: string;
  currentWeekEndDate: string;
  activeWeekStartDate: string;
  selectedDateStr: string;
  isLoading: boolean;
  error: string | null;
  // Sunday Reminder
  isSunday: boolean;
  showSundayReminder: boolean;
  dismissSundayReminder: () => void;
  // Pending Previous Reports
  pendingPreviousWeeks: WeekSummary[];
  // Active week summaries & calculations
  activeWeekSessions: ServiceSession[];
  activeWeekTotalMinutes: number;
  activeWeekTotalHoursDecimal: number;
  activeWeekReport: WeeklyReport | null;
  todayTotalMinutes: number;
  selectedDateTotalMinutes: number;
  selectedDateSessions: ServiceSession[];
  allWeekSummaries: WeekSummary[];
  // Actions
  setActiveWeek: (weekStartDate: string) => void;
  setSelectedDate: (dateStr: string) => void;
  goToCurrentWeek: () => void;
  addSession: (date: string, hours: number, minutes: number) => Promise<ServiceSession>;
  updateSession: (id: string, date: string, hours: number, minutes: number) => Promise<void>;
  deleteSession: (id: string) => Promise<void>;
  saveReportDraft: (report: Partial<WeeklyReport> & { weekStartDate: string }) => Promise<WeeklyReport>;
  confirmReportSubmission: (weekStartDate: string) => Promise<WeeklyReport>;
  refreshAll: () => Promise<void>;
}

const MissionContext = createContext<MissionContextValue | null>(null);

const SUNDAY_REMINDER_DISMISSED_KEY = 'lds_sunday_reminder_dismissed';

export const MissionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sessions, setSessions] = useState<ServiceSession[]>([]);
  const [reports, setReports] = useState<WeeklyReport[]>([]);
  const [settings, setSettings] = useState<AppSettings>({
    weeklyGoalHours: DEFAULT_WEEKLY_GOAL_HOURS,
    installedAt: formatToLocalDateString(new Date()),
  });

  const [todayDateStr, setTodayDateStr] = useState<string>(() => formatToLocalDateString(new Date()));
  const [activeWeekStartDate, setActiveWeekStartDate] = useState<string>(() => getWeekStartDateStr(new Date()));
  const [selectedDateStr, setSelectedDateStr] = useState<string>(() => formatToLocalDateString(new Date()));
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [sundayDismissed, setSundayDismissed] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem(SUNDAY_REMINDER_DISMISSED_KEY) === 'true';
    } catch {
      return false;
    }
  });

  // Calculate current week identifiers derived strictly from device local time
  const currentWeekStartDate = useMemo(() => getWeekStartDateStr(todayDateStr), [todayDateStr]);
  const currentWeekEndDate = useMemo(() => getWeekEndDateStr(currentWeekStartDate), [currentWeekStartDate]);

  // Ensure today's date updates if app stays open past midnight or resumes from background
  const checkCurrentDate = useCallback(() => {
    const freshToday = formatToLocalDateString(new Date());
    setTodayDateStr((prev) => {
      if (prev !== freshToday) {
        // Rollover happened!
        const freshMonday = getWeekStartDateStr(freshToday);
        setActiveWeekStartDate(freshMonday);
        setSelectedDateStr(freshToday);
        return freshToday;
      }
      return prev;
    });
  }, []);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        checkCurrentDate();
      }
    };

    window.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', checkCurrentDate);

    // Also interval check every 30 seconds
    const timer = setInterval(checkCurrentDate, 30000);

    return () => {
      window.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', checkCurrentDate);
      clearInterval(timer);
    };
  }, [checkCurrentDate]);

  // Load initial data from IndexedDB
  const refreshAll = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const [loadedSessions, loadedReports, loadedSettings] = await Promise.all([
        db.getAllSessions(),
        db.getAllReports(),
        db.getAppSettings(),
      ]);

      setSessions(loadedSessions);
      setReports(loadedReports);
      setSettings(loadedSettings);
    } catch (err: unknown) {
      console.error('Failed to load mission data:', err);
      setError(err instanceof Error ? err.message : 'Failed to load local records');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  // Sunday Reminder Logic
  const isSunday = useMemo(() => isTodaySunday(), [todayDateStr]);
  const showSundayReminder = isSunday && !sundayDismissed;

  const dismissSundayReminder = useCallback(() => {
    setSundayDismissed(true);
    try {
      sessionStorage.setItem(SUNDAY_REMINDER_DISMISSED_KEY, 'true');
    } catch {
      // ignore
    }
  }, []);

  // Compute Active Week's sessions & totals
  const activeWeekSessions = useMemo(() => {
    return sessions.filter((s) => s.weekStartDate === activeWeekStartDate);
  }, [sessions, activeWeekStartDate]);

  const activeWeekTotalMinutes = useMemo(() => {
    return activeWeekSessions.reduce((acc, curr) => acc + curr.durationMinutes, 0);
  }, [activeWeekSessions]);

  const activeWeekTotalHoursDecimal = useMemo(() => {
    return minutesToDecimalHours(activeWeekTotalMinutes);
  }, [activeWeekTotalMinutes]);

  const activeWeekReport = useMemo(() => {
    return reports.find((r) => r.weekStartDate === activeWeekStartDate) || null;
  }, [reports, activeWeekStartDate]);

  // Today's total minutes
  const todayTotalMinutes = useMemo(() => {
    return sessions
      .filter((s) => s.date === todayDateStr)
      .reduce((acc, curr) => acc + curr.durationMinutes, 0);
  }, [sessions, todayDateStr]);

  // Selected date's sessions & total
  const selectedDateSessions = useMemo(() => {
    return sessions.filter((s) => s.date === selectedDateStr);
  }, [sessions, selectedDateStr]);

  const selectedDateTotalMinutes = useMemo(() => {
    return selectedDateSessions.reduce((acc, curr) => acc + curr.durationMinutes, 0);
  }, [selectedDateSessions]);

  // Aggregate all weeks for History and Pending check
  const allWeekSummaries = useMemo<WeekSummary[]>(() => {
    // Collect all unique week start dates from both sessions and reports, plus current week
    const weekSet = new Set<string>();
    weekSet.add(currentWeekStartDate);

    for (const s of sessions) {
      if (s.weekStartDate) weekSet.add(s.weekStartDate);
    }
    for (const r of reports) {
      if (r.weekStartDate) weekSet.add(r.weekStartDate);
    }

    const sortedWeeks = Array.from(weekSet).sort((a, b) => b.localeCompare(a));

    return sortedWeeks.map((weekStart) => {
      const weekEnd = getWeekEndDateStr(weekStart);
      const weekSessions = sessions.filter((s) => s.weekStartDate === weekStart);
      const totalMins = weekSessions.reduce((acc, curr) => acc + curr.durationMinutes, 0);
      const rep = reports.find((r) => r.weekStartDate === weekStart) || null;

      let status: WeekSummary['reportStatus'] = 'not_started';
      if (rep?.isSubmitted) {
        status = 'submitted';
      } else if (rep) {
        // Check if partially filled
        const hasInputs =
          rep.gospelStudyDays !== null ||
          rep.companionMinisteringCount !== null ||
          rep.journalingCount !== null;
        status = hasInputs ? 'in_progress' : 'pending_submission';
      } else if (weekStart !== currentWeekStartDate && totalMins > 0) {
        status = 'pending_submission';
      }

      const goal = settings.weeklyGoalHours || DEFAULT_WEEKLY_GOAL_HOURS;
      const progress = Math.min(100, Math.round((totalMins / (goal * 60)) * 1000) / 10);

      return {
        weekStartDate: weekStart,
        weekEndDate: weekEnd,
        formattedDateRange: formatWeekDateRange(weekStart, weekEnd),
        isCurrentWeek: weekStart === currentWeekStartDate,
        totalMinutes: totalMins,
        totalHoursDecimal: minutesToDecimalHours(totalMins),
        sessionCount: weekSessions.length,
        goalHours: goal,
        progressPercent: progress,
        report: rep,
        reportStatus: status,
      };
    });
  }, [sessions, reports, currentWeekStartDate, settings.weeklyGoalHours]);

  // Check for pending previous unsubmitted weeks (strictly earlier than current week)
  const pendingPreviousWeeks = useMemo(() => {
    return allWeekSummaries.filter(
      (w) => !w.isCurrentWeek && w.reportStatus !== 'submitted' && (w.totalMinutes > 0 || w.report !== null)
    );
  }, [allWeekSummaries]);

  // Session Actions
  const addSession = useCallback(
    async (date: string, hours: number, minutes: number) => {
      const duration = hours * 60 + minutes;
      if (duration <= 0) {
        throw new Error('Please enter a duration greater than 0 minutes.');
      }

      const weekStart = getWeekStartDateStr(date);
      const newSession: ServiceSession = {
        id: `sess_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        date,
        durationMinutes: duration,
        createdAt: new Date().toISOString(),
        weekStartDate: weekStart,
      };

      await db.saveSession(newSession);

      setSessions((prev) => {
        const next = [newSession, ...prev];
        return next.sort((a, b) => {
          if (a.date !== b.date) return b.date.localeCompare(a.date);
          return b.createdAt.localeCompare(a.createdAt);
        });
      });

      return newSession;
    },
    []
  );

  const updateSession = useCallback(
    async (id: string, date: string, hours: number, minutes: number) => {
      const duration = hours * 60 + minutes;
      if (duration <= 0) {
        throw new Error('Please enter a duration greater than 0 minutes.');
      }

      const existing = sessions.find((s) => s.id === id);
      if (!existing) {
        throw new Error('Session not found.');
      }

      const weekStart = getWeekStartDateStr(date);
      const updated: ServiceSession = {
        ...existing,
        date,
        durationMinutes: duration,
        weekStartDate: weekStart,
      };

      await db.saveSession(updated);

      setSessions((prev) => {
        const next = prev.map((s) => (s.id === id ? updated : s));
        return next.sort((a, b) => {
          if (a.date !== b.date) return b.date.localeCompare(a.date);
          return b.createdAt.localeCompare(a.createdAt);
        });
      });
    },
    [sessions]
  );

  const deleteSession = useCallback(async (id: string) => {
    await db.deleteSession(id);
    setSessions((prev) => prev.filter((s) => s.id !== id));
  }, []);

  // Report Actions
  const saveReportDraft = useCallback(
    async (draft: Partial<WeeklyReport> & { weekStartDate: string }): Promise<WeeklyReport> => {
      const weekStart = draft.weekStartDate;
      const weekEnd = getWeekEndDateStr(weekStart);

      // Calculate suggested hours from current sessions of that week
      const weekSessions = sessions.filter((s) => s.weekStartDate === weekStart);
      const totalMins = weekSessions.reduce((acc, curr) => acc + curr.durationMinutes, 0);
      const calculatedHours = minutesToDecimalHours(totalMins);

      const existing = reports.find((r) => r.weekStartDate === weekStart);

      const isManual = draft.isHoursManuallyOverridden ?? existing?.isHoursManuallyOverridden ?? false;
      const manualHours = draft.manualHours ?? existing?.manualHours ?? null;

      const finalReportedHours = isManual && manualHours !== null ? manualHours : calculatedHours;

      const reportToSave: WeeklyReport = {
        id: existing?.id || `report_${weekStart}`,
        weekStartDate: weekStart,
        weekEndDate: weekEnd,
        gospelStudyDays: draft.gospelStudyDays !== undefined ? draft.gospelStudyDays : (existing?.gospelStudyDays ?? null),
        companionMinisteringCount:
          draft.companionMinisteringCount !== undefined
            ? draft.companionMinisteringCount
            : (existing?.companionMinisteringCount ?? null),
        journalingCount:
          draft.journalingCount !== undefined ? draft.journalingCount : (existing?.journalingCount ?? null),
        calculatedHours,
        reportedHours: draft.reportedHours !== undefined ? draft.reportedHours : finalReportedHours,
        isHoursManuallyOverridden: isManual,
        manualHours,
        isSubmitted: existing?.isSubmitted ?? false,
        submittedAt: existing?.submittedAt ?? null,
        lastUpdatedAt: new Date().toISOString(),
      };

      await db.saveReport(reportToSave);

      setReports((prev) => {
        const index = prev.findIndex((r) => r.weekStartDate === weekStart);
        if (index >= 0) {
          const next = [...prev];
          next[index] = reportToSave;
          return next;
        } else {
          return [reportToSave, ...prev];
        }
      });

      return reportToSave;
    },
    [sessions, reports]
  );

  const confirmReportSubmission = useCallback(
    async (weekStartDate: string): Promise<WeeklyReport> => {
      const existing = reports.find((r) => r.weekStartDate === weekStartDate);
      if (!existing) {
        throw new Error('Report draft not found. Please save report details first.');
      }

      // Validate that all required metrics are filled
      if (existing.gospelStudyDays === null || existing.gospelStudyDays < 0 || existing.gospelStudyDays > 7) {
        throw new Error('Please enter valid Gospel Study Days (0 to 7).');
      }
      if (existing.companionMinisteringCount === null || existing.companionMinisteringCount < 0) {
        throw new Error('Please enter valid Companion Ministering count (0 or more).');
      }
      if (existing.journalingCount === null || existing.journalingCount < 0) {
        throw new Error('Please enter valid Journaling / Testimony count (0 or more).');
      }
      if (existing.reportedHours === null || existing.reportedHours < 0) {
        throw new Error('Please enter valid Service Hours.');
      }

      const confirmedReport: WeeklyReport = {
        ...existing,
        isSubmitted: true,
        submittedAt: new Date().toISOString(),
        lastUpdatedAt: new Date().toISOString(),
      };

      await db.saveReport(confirmedReport);

      setReports((prev) => prev.map((r) => (r.weekStartDate === weekStartDate ? confirmedReport : r)));

      return confirmedReport;
    },
    [reports]
  );

  const goToCurrentWeek = useCallback(() => {
    setActiveWeekStartDate(currentWeekStartDate);
    setSelectedDateStr(todayDateStr);
  }, [currentWeekStartDate, todayDateStr]);

  const value: MissionContextValue = {
    sessions,
    reports,
    settings,
    todayDateStr,
    currentWeekStartDate,
    currentWeekEndDate,
    activeWeekStartDate,
    selectedDateStr,
    isLoading,
    error,
    isSunday,
    showSundayReminder,
    dismissSundayReminder,
    pendingPreviousWeeks,
    activeWeekSessions,
    activeWeekTotalMinutes,
    activeWeekTotalHoursDecimal,
    activeWeekReport,
    todayTotalMinutes,
    selectedDateTotalMinutes,
    selectedDateSessions,
    allWeekSummaries,
    setActiveWeek: setActiveWeekStartDate,
    setSelectedDate: setSelectedDateStr,
    goToCurrentWeek,
    addSession,
    updateSession,
    deleteSession,
    saveReportDraft,
    confirmReportSubmission,
    refreshAll,
  };

  return <MissionContext.Provider value={value}>{children}</MissionContext.Provider>;
};

export function useMission(): MissionContextValue {
  const context = useContext(MissionContext);
  if (!context) {
    throw new Error('useMission must be used within a MissionProvider');
  }
  return context;
}
