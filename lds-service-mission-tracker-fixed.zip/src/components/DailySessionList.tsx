import React, { useState } from 'react';
import { AlertCircle, Clock, Edit2, Plus, Trash2 } from 'lucide-react';
import { ServiceSession } from '../types';
import { formatFullDate, formatMinutes, getWeekStartDateStr } from '../utils/dateUtils';
import { useMission } from '../context/MissionContext';

interface DailySessionListProps {
  date: string;
  sessions: ServiceSession[];
  onAddSession: () => void;
  onEditSession: (session: ServiceSession) => void;
}

export const DailySessionList: React.FC<DailySessionListProps> = ({
  date,
  sessions,
  onAddSession,
  onEditSession,
}) => {
  const { deleteSession, reports } = useMission();
  const [sessionToDelete, setSessionToDelete] = useState<ServiceSession | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const totalMinutes = sessions.reduce((acc, curr) => acc + curr.durationMinutes, 0);

  // Check if target week is already submitted
  const weekStart = getWeekStartDateStr(date);
  const weekReport = reports.find((r) => r.weekStartDate === weekStart);
  const isWeekSubmitted = weekReport?.isSubmitted ?? false;

  const handleDeleteConfirm = async () => {
    if (!sessionToDelete) return;
    try {
      setIsDeleting(true);
      await deleteSession(sessionToDelete.id);
      setSessionToDelete(null);
    } catch (err) {
      console.error('Failed to delete session:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-4 shadow-md">
      {/* Day Header */}
      <div className="flex items-center justify-between pb-3 border-b border-[#293441]">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#9AA7B5] block">
            Selected Day Sessions
          </span>
          <h3 className="text-sm font-bold text-[#F4F7FA] mt-0.5">
            {formatFullDate(date)}
          </h3>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#9AA7B5] block">
            Daily Total
          </span>
          <span className="text-base font-extrabold text-[#A3FF5F] font-mono-numbers">
            {formatMinutes(totalMinutes)}
          </span>
        </div>
      </div>

      {/* Warning if week is submitted */}
      {isWeekSubmitted && (
        <div className="mt-3 p-2.5 bg-amber-950/40 border border-amber-600/40 rounded-xl text-amber-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Note: Weekly report for this period has already been submitted.</span>
        </div>
      )}

      {/* Sessions List */}
      <div className="mt-3 space-y-2.5">
        {sessions.length === 0 ? (
          <div className="py-8 text-center bg-[#0B0F14]/40 rounded-xl border border-dashed border-[#293441]">
            <Clock className="w-8 h-8 text-[#9AA7B5]/40 mx-auto mb-2" />
            <p className="text-xs text-[#9AA7B5] font-medium">
              No service sessions recorded for this day.
            </p>
            <button
              type="button"
              onClick={onAddSession}
              className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#1B2530] text-[#A3FF5F] text-xs font-bold border border-[#293441] hover:border-[#A3FF5F]/50 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log Service Hours</span>
            </button>
          </div>
        ) : (
          sessions.map((session, index) => {
            return (
              <div
                key={session.id}
                className="flex items-center justify-between p-3 rounded-xl bg-[#1B2530]/70 border border-[#293441] hover:border-[#9AA7B5]/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#0B0F14] border border-[#293441] flex items-center justify-center text-xs font-bold text-[#9AA7B5]">
                    #{index + 1}
                  </div>
                  <div>
                    <span className="text-base font-extrabold text-[#F4F7FA] font-mono-numbers block">
                      {formatMinutes(session.durationMinutes)}
                    </span>
                    <span className="text-[10px] text-[#9AA7B5] block">
                      {session.durationMinutes} minutes recorded
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onEditSession(session)}
                    className="w-9 h-9 rounded-lg bg-[#0B0F14]/80 text-[#9AA7B5] hover:text-[#A3FF5F] flex items-center justify-center transition-colors"
                    aria-label="Edit session"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setSessionToDelete(session)}
                    className="w-9 h-9 rounded-lg bg-[#0B0F14]/80 text-[#9AA7B5] hover:text-red-400 flex items-center justify-center transition-colors"
                    aria-label="Delete session"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Session Button */}
      {sessions.length > 0 && (
        <button
          type="button"
          onClick={onAddSession}
          className="w-full mt-3 min-h-[44px] rounded-xl bg-[#1B2530] border border-[#293441] hover:border-[#A3FF5F]/50 text-[#A3FF5F] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors active:scale-[0.99]"
        >
          <Plus className="w-4 h-4" />
          <span>Add Another Session Today</span>
        </button>
      )}

      {/* Delete Confirmation Modal */}
      {sessionToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm bg-[#141B23] border border-[#293441] rounded-2xl p-5 shadow-2xl">
            <h4 className="text-base font-bold text-[#F4F7FA]">Delete Service Session?</h4>
            <p className="mt-2 text-xs text-[#9AA7B5] leading-relaxed">
              Are you sure you want to delete this session of{' '}
              <strong className="text-[#F4F7FA] font-mono-numbers">
                {formatMinutes(sessionToDelete.durationMinutes)}
              </strong>{' '}
              on {formatFullDate(sessionToDelete.date)}? This action cannot be undone.
            </p>

            <div className="mt-5 flex gap-2.5">
              <button
                type="button"
                onClick={() => setSessionToDelete(null)}
                disabled={isDeleting}
                className="flex-1 py-2.5 rounded-xl bg-[#1B2530] border border-[#293441] text-xs font-semibold text-[#F4F7FA] hover:bg-[#253241]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={isDeleting}
                className="flex-1 py-2.5 rounded-xl bg-red-600/90 text-white text-xs font-bold hover:bg-red-500 shadow-md transition-colors"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
