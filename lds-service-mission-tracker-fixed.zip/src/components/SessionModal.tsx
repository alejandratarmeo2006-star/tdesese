import React, { useState, useEffect } from 'react';
import { AlertTriangle, Clock, X } from 'lucide-react';
import { ServiceSession } from '../types';
import { formatMinutes, formatToLocalDateString, getWeekStartDateStr } from '../utils/dateUtils';
import { useMission } from '../context/MissionContext';

interface SessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionToEdit?: ServiceSession | null;
  defaultDate?: string;
}

export const SessionModal: React.FC<SessionModalProps> = ({
  isOpen,
  onClose,
  sessionToEdit,
  defaultDate,
}) => {
  const { addSession, updateSession, reports } = useMission();

  const [date, setDate] = useState<string>(() => defaultDate || formatToLocalDateString(new Date()));
  const [hours, setHours] = useState<string>('1');
  const [minutes, setMinutes] = useState<string>('0');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (sessionToEdit) {
      setDate(sessionToEdit.date);
      setHours(String(Math.floor(sessionToEdit.durationMinutes / 60)));
      setMinutes(String(sessionToEdit.durationMinutes % 60));
    } else if (defaultDate) {
      setDate(defaultDate);
      setHours('1');
      setMinutes('0');
    } else {
      setDate(formatToLocalDateString(new Date()));
      setHours('1');
      setMinutes('0');
    }
    setError(null);
  }, [sessionToEdit, defaultDate, isOpen]);

  if (!isOpen) return null;

  const parsedHours = parseInt(hours, 10) || 0;
  const parsedMinutes = parseInt(minutes, 10) || 0;
  const totalMinutes = parsedHours * 60 + parsedMinutes;

  // Check if target week is already submitted
  const targetWeekStart = getWeekStartDateStr(date);
  const associatedReport = reports.find((r) => r.weekStartDate === targetWeekStart);
  const isTargetWeekSubmitted = associatedReport?.isSubmitted ?? false;

  const handleQuickAdd = (addH: number, addM: number) => {
    let newH = parsedHours + addH;
    let newM = parsedMinutes + addM;
    if (newM >= 60) {
      newH += Math.floor(newM / 60);
      newM = newM % 60;
    }
    setHours(String(newH));
    setMinutes(String(newM));
  };

  const handleSetPreset = (presetH: number, presetM: number) => {
    setHours(String(presetH));
    setMinutes(String(presetM));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!date) {
      setError('Please select a valid date.');
      return;
    }
    if (parsedHours < 0) {
      setError('Hours cannot be negative.');
      return;
    }
    if (parsedMinutes < 0 || parsedMinutes > 59) {
      setError('Minutes must be between 0 and 59.');
      return;
    }
    if (totalMinutes <= 0) {
      setError('Total duration must be greater than 0 minutes.');
      return;
    }

    try {
      setIsSubmitting(true);
      if (sessionToEdit) {
        await updateSession(sessionToEdit.id, date, parsedHours, parsedMinutes);
      } else {
        await addSession(date, parsedHours, parsedMinutes);
      }
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save session');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#141B23] border-t sm:border border-[#293441] rounded-t-3xl sm:rounded-2xl p-6 shadow-2xl overflow-y-auto max-h-[92vh]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="session-modal-title"
      >
        {/* Mobile handle indicator */}
        <div className="w-12 h-1 bg-[#293441] rounded-full mx-auto mb-4 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#293441]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#A3FF5F]/10 border border-[#A3FF5F]/30 flex items-center justify-center text-[#A3FF5F]">
              <Clock className="w-4 h-4" />
            </div>
            <h2 id="session-modal-title" className="text-lg font-bold text-[#F4F7FA]">
              {sessionToEdit ? 'Edit Service Session' : 'Record Service Session'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-lg bg-[#1B2530] text-[#9AA7B5] hover:text-[#F4F7FA] flex items-center justify-center transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning if week is already submitted */}
        {isTargetWeekSubmitted && (
          <div className="mt-4 p-3 bg-amber-950/60 border border-amber-600/50 rounded-xl text-amber-200 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block text-amber-300">Notice: Report Already Submitted</span>
              This session falls in a week whose weekly report was marked submitted. Modifying records here will make local totals differ from the Microsoft Forms submission.
            </div>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="mt-4 p-3 bg-red-950/70 border border-red-700/60 rounded-xl text-red-200 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Date Picker */}
          <div>
            <label htmlFor="session-date" className="block text-xs font-semibold text-[#9AA7B5] uppercase tracking-wider mb-1.5">
              Service Date
            </label>
            <input
              id="session-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-[#1B2530] border border-[#293441] rounded-xl px-3.5 py-2.5 text-sm font-medium text-[#F4F7FA] focus:outline-none focus:border-[#A3FF5F] focus:ring-1 focus:ring-[#A3FF5F] transition-colors"
              required
            />
          </div>

          {/* Duration: Hours & Minutes */}
          <div>
            <label className="block text-xs font-semibold text-[#9AA7B5] uppercase tracking-wider mb-1.5">
              Session Duration
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    step="1"
                    inputMode="numeric"
                    value={hours}
                    onChange={(e) => setHours(e.target.value)}
                    placeholder="0"
                    className="w-full bg-[#1B2530] border border-[#293441] rounded-xl px-3.5 py-3 text-lg font-bold font-mono-numbers text-[#F4F7FA] focus:outline-none focus:border-[#A3FF5F] focus:ring-1 focus:ring-[#A3FF5F] pr-10 transition-colors"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold text-[#9AA7B5]">
                    hrs
                  </span>
                </div>
              </div>

              <div>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max="59"
                    step="1"
                    inputMode="numeric"
                    value={minutes}
                    onChange={(e) => setMinutes(e.target.value)}
                    placeholder="0"
                    className="w-full bg-[#1B2530] border border-[#293441] rounded-xl px-3.5 py-3 text-lg font-bold font-mono-numbers text-[#F4F7FA] focus:outline-none focus:border-[#A3FF5F] focus:ring-1 focus:ring-[#A3FF5F] pr-10 transition-colors"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold text-[#9AA7B5]">
                    min
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Presets & Add chips */}
          <div>
            <span className="block text-[11px] font-medium text-[#9AA7B5] mb-2">
              Quick duration presets:
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleSetPreset(0, 30)}
                className="px-2.5 py-1.5 rounded-lg bg-[#1B2530] border border-[#293441] text-xs font-medium text-[#F4F7FA] hover:border-[#A3FF5F]/50 transition-colors active:scale-95"
              >
                30m
              </button>
              <button
                type="button"
                onClick={() => handleSetPreset(1, 0)}
                className="px-2.5 py-1.5 rounded-lg bg-[#1B2530] border border-[#293441] text-xs font-medium text-[#F4F7FA] hover:border-[#A3FF5F]/50 transition-colors active:scale-95"
              >
                1h
              </button>
              <button
                type="button"
                onClick={() => handleSetPreset(1, 30)}
                className="px-2.5 py-1.5 rounded-lg bg-[#1B2530] border border-[#293441] text-xs font-medium text-[#F4F7FA] hover:border-[#A3FF5F]/50 transition-colors active:scale-95"
              >
                1h 30m
              </button>
              <button
                type="button"
                onClick={() => handleSetPreset(2, 0)}
                className="px-2.5 py-1.5 rounded-lg bg-[#1B2530] border border-[#293441] text-xs font-medium text-[#F4F7FA] hover:border-[#A3FF5F]/50 transition-colors active:scale-95"
              >
                2h
              </button>
              <button
                type="button"
                onClick={() => handleSetPreset(3, 0)}
                className="px-2.5 py-1.5 rounded-lg bg-[#1B2530] border border-[#293441] text-xs font-medium text-[#F4F7FA] hover:border-[#A3FF5F]/50 transition-colors active:scale-95"
              >
                3h
              </button>
              <button
                type="button"
                onClick={() => handleQuickAdd(0, 15)}
                className="px-2.5 py-1.5 rounded-lg bg-[#1B2530]/60 border border-[#293441] text-xs font-medium text-[#A3FF5F] hover:bg-[#1B2530] transition-colors active:scale-95"
              >
                +15m
              </button>
            </div>
          </div>

          {/* Total Duration Summary Preview */}
          <div className="p-3 bg-[#0B0F14] border border-[#293441] rounded-xl flex items-center justify-between">
            <span className="text-xs font-medium text-[#9AA7B5]">Total session duration:</span>
            <span className="text-base font-extrabold text-[#A3FF5F] font-mono-numbers">
              {formatMinutes(totalMinutes)}
              <span className="text-xs font-normal text-[#9AA7B5] ml-1">
                ({totalMinutes} min)
              </span>
            </span>
          </div>

          {/* Actions */}
          <div className="pt-2 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 min-h-[48px] rounded-xl bg-[#1B2530] border border-[#293441] text-[#F4F7FA] text-sm font-semibold hover:bg-[#253241] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || totalMinutes <= 0}
              className="flex-1 min-h-[48px] rounded-xl bg-[#A3FF5F] text-[#0B0F14] text-sm font-bold shadow-[0_0_16px_rgba(163,255,95,0.3)] hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? 'Saving...' : sessionToEdit ? 'Update Session' : 'Save Session'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
