import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Calendar,
  CheckCircle2,
  Clock,
  ExternalLink,
  FileText,
  Plus,
} from 'lucide-react';
import { useMission } from '../context/MissionContext';
import { ServiceSession, WeekSummary } from '../types';
import {
  formatFullDate,
  formatMinutes,
  getDaysOfWeek,
  minutesToDecimalHours,
} from '../utils/dateUtils';
import { GoalProgressCard } from './GoalProgressCard';
import { DailySessionList } from './DailySessionList';

interface HistoryViewProps {
  onOpenReportForWeek: (weekStartDate: string) => void;
  onAddSessionForDate: (dateStr: string) => void;
  onEditSession: (session: ServiceSession) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  onOpenReportForWeek,
  onAddSessionForDate,
  onEditSession,
}) => {
  const {
    allWeekSummaries,
    sessions,
    reports,
    currentWeekStartDate,
    todayDateStr,
    goToCurrentWeek,
  } = useMission();

  const [inspectedWeekStart, setInspectedWeekStart] = useState<string | null>(null);
  const [selectedDayInWeek, setSelectedDayInWeek] = useState<string | null>(null);

  // If inspecting a specific week
  const inspectedWeekSummary = allWeekSummaries.find(
    (w) => w.weekStartDate === inspectedWeekStart
  );

  const inspectedSessions = sessions.filter(
    (s) => s.weekStartDate === inspectedWeekStart
  );

  const inspectedReport = reports.find(
    (r) => r.weekStartDate === inspectedWeekStart
  );

  // Status Badge Helper
  const renderStatusBadge = (status: WeekSummary['reportStatus'], submittedAt?: string | null) => {
    switch (status) {
      case 'submitted':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 text-[10px] font-bold">
            <CheckCircle2 className="w-3 h-3" />
            <span>Submitted</span>
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-blue-950/80 text-blue-400 border border-blue-800/60 text-[10px] font-bold">
            <span>In Progress</span>
          </span>
        );
      case 'pending_submission':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-amber-950/80 text-amber-400 border border-amber-800/60 text-[10px] font-bold">
            <AlertTriangle className="w-3 h-3" />
            <span>Pending Submission</span>
          </span>
        );
      case 'not_started':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-[#1B2530] text-[#9AA7B5] border border-[#293441] text-[10px] font-bold">
            <span>Not Started</span>
          </span>
        );
    }
  };

  // ----------------------------------------------------
  // Detailed Single Week View
  // ----------------------------------------------------
  if (inspectedWeekStart && inspectedWeekSummary) {
    const daysInWeek = getDaysOfWeek(inspectedWeekStart);
    const activeDay = selectedDayInWeek || inspectedWeekStart;
    const activeDaySessions = inspectedSessions.filter((s) => s.date === activeDay);

    return (
      <div className="space-y-4 pb-24 animate-in fade-in">
        {/* Top Header & Back Button */}
        <div className="flex items-center justify-between pb-2 border-b border-[#293441]">
          <button
            type="button"
            onClick={() => {
              setInspectedWeekStart(null);
              setSelectedDayInWeek(null);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#141B23] border border-[#293441] text-xs font-semibold text-[#F4F7FA] hover:text-[#A3FF5F] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>All Weeks</span>
          </button>

          <div className="flex items-center gap-2">
            {inspectedWeekSummary.isCurrentWeek ? (
              <span className="px-2 py-0.5 rounded bg-[#A3FF5F]/20 text-[#A3FF5F] text-[10px] font-extrabold uppercase tracking-wider">
                Current Week
              </span>
            ) : (
              <button
                type="button"
                onClick={() => {
                  goToCurrentWeek();
                  setInspectedWeekStart(null);
                }}
                className="text-[11px] font-semibold text-[#A3FF5F] hover:underline"
              >
                Go to Current Week &rarr;
              </button>
            )}
          </div>
        </div>

        {/* Week Goal Card */}
        <GoalProgressCard
          weekStartDate={inspectedWeekSummary.weekStartDate}
          weekEndDate={inspectedWeekSummary.weekEndDate}
          totalMinutes={inspectedWeekSummary.totalMinutes}
          goalHours={inspectedWeekSummary.goalHours}
          reportStatus={inspectedWeekSummary.reportStatus}
          onOpenReport={() => onOpenReportForWeek(inspectedWeekSummary.weekStartDate)}
        />

        {/* Warning if submitted */}
        {inspectedReport?.isSubmitted && (
          <div className="p-3 bg-amber-950/50 border border-amber-600/50 rounded-2xl text-amber-200 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-amber-300">Historical Submitted Week</strong>
              This week's report was officially confirmed submitted on{' '}
              {new Date(inspectedReport.submittedAt || '').toLocaleString()}. Any edits to sessions or report metrics may diverge from the submitted Microsoft Forms record.
            </div>
          </div>
        )}

        {/* 7-Day Mini Breakdown */}
        <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-3.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#9AA7B5] block mb-2 px-1">
            Days Breakdown (Mon – Sun)
          </span>

          <div className="grid grid-cols-7 gap-1">
            {daysInWeek.map((d) => {
              const dayMins = inspectedSessions
                .filter((s) => s.date === d.date)
                .reduce((acc, curr) => acc + curr.durationMinutes, 0);
              const isSelected = d.date === activeDay;

              return (
                <button
                  key={d.date}
                  type="button"
                  onClick={() => setSelectedDayInWeek(d.date)}
                  className={`flex flex-col items-center py-2 px-1 rounded-xl transition-colors ${
                    isSelected
                      ? 'bg-[#1B2530] border-2 border-[#A3FF5F]'
                      : 'bg-[#0B0F14]/70 border border-[#293441]'
                  }`}
                >
                  <span className="text-[10px] font-bold text-[#9AA7B5] uppercase">
                    {d.dayName}
                  </span>
                  <span className="text-xs font-bold text-[#F4F7FA] my-0.5 font-mono-numbers">
                    {d.dayNumber}
                  </span>
                  <span
                    className={`text-[9px] font-semibold font-mono-numbers ${
                      dayMins > 0 ? 'text-[#A3FF5F]' : 'text-[#9AA7B5]/40'
                    }`}
                  >
                    {formatMinutes(dayMins)}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Day Sessions */}
        <DailySessionList
          date={activeDay}
          sessions={activeDaySessions}
          onAddSession={() => onAddSessionForDate(activeDay)}
          onEditSession={onEditSession}
        />

        {/* Report Metrics Summary Card */}
        <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#293441]">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#A3FF5F]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AA7B5]">
                Weekly Report Status
              </h3>
            </div>
            {renderStatusBadge(inspectedWeekSummary.reportStatus, inspectedReport?.submittedAt)}
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-[#0B0F14] border border-[#293441]">
              <span className="text-[10px] text-[#9AA7B5] block">A. Gospel Study</span>
              <span className="text-sm font-bold text-[#F4F7FA] font-mono-numbers mt-0.5 block">
                {inspectedReport?.gospelStudyDays !== null && inspectedReport?.gospelStudyDays !== undefined
                  ? `${inspectedReport.gospelStudyDays} days`
                  : 'Not entered'}
              </span>
            </div>

            <div className="p-2.5 rounded-xl bg-[#0B0F14] border border-[#293441]">
              <span className="text-[10px] text-[#9AA7B5] block">B. Companion Ministering</span>
              <span className="text-sm font-bold text-[#F4F7FA] font-mono-numbers mt-0.5 block">
                {inspectedReport?.companionMinisteringCount !== null && inspectedReport?.companionMinisteringCount !== undefined
                  ? `${inspectedReport.companionMinisteringCount} times`
                  : 'Not entered'}
              </span>
            </div>

            <div className="p-2.5 rounded-xl bg-[#0B0F14] border border-[#293441]">
              <span className="text-[10px] text-[#9AA7B5] block">C. Journaling / Testimony</span>
              <span className="text-sm font-bold text-[#F4F7FA] font-mono-numbers mt-0.5 block">
                {inspectedReport?.journalingCount !== null && inspectedReport?.journalingCount !== undefined
                  ? `${inspectedReport.journalingCount} times`
                  : 'Not entered'}
              </span>
            </div>

            <div className="p-2.5 rounded-xl bg-[#0B0F14] border border-[#293441]">
              <span className="text-[10px] text-[#9AA7B5] block">D. Final Reported Hours</span>
              <span className="text-sm font-bold text-[#A3FF5F] font-mono-numbers mt-0.5 block">
                {inspectedReport?.reportedHours !== undefined
                  ? `${inspectedReport.reportedHours}h`
                  : `${inspectedWeekSummary.totalHoursDecimal}h (calc)`}
              </span>
            </div>
          </div>

          {inspectedReport?.submittedAt && (
            <div className="mt-3 text-[11px] text-[#9AA7B5] text-center">
              Confirmed submitted: {new Date(inspectedReport.submittedAt).toLocaleString()}
            </div>
          )}

          <button
            type="button"
            onClick={() => onOpenReportForWeek(inspectedWeekSummary.weekStartDate)}
            className="w-full mt-3 min-h-[44px] rounded-xl bg-[#1B2530] border border-[#293441] hover:border-[#A3FF5F]/50 text-[#F4F7FA] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>{inspectedReport?.isSubmitted ? 'Inspect / Re-open Report' : 'Complete Weekly Report'}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  // ----------------------------------------------------
  // All Weeks List View
  // ----------------------------------------------------
  return (
    <div className="space-y-4 pb-24 animate-in fade-in">
      <div className="flex items-center justify-between pb-1">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#A3FF5F] block">
            Archive &amp; Inspection
          </span>
          <h2 className="text-xl font-extrabold text-[#F4F7FA]">Service Weeks History</h2>
        </div>
        <span className="text-xs font-semibold text-[#9AA7B5] font-mono-numbers">
          {allWeekSummaries.length} {allWeekSummaries.length === 1 ? 'week' : 'weeks'}
        </span>
      </div>

      <div className="space-y-3">
        {allWeekSummaries.map((week) => {
          return (
            <div
              key={week.weekStartDate}
              onClick={() => {
                setInspectedWeekStart(week.weekStartDate);
                setSelectedDayInWeek(week.weekStartDate);
              }}
              className={`p-4 rounded-2xl cursor-pointer transition-all duration-200 border ${
                week.isCurrentWeek
                  ? 'bg-gradient-to-br from-[#141B23] to-[#1B2530] border-[#A3FF5F]/50 shadow-[0_0_15px_rgba(163,255,95,0.1)]'
                  : 'bg-[#141B23] border-[#293441] hover:border-[#9AA7B5]/40'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[#F4F7FA]">
                      {week.formattedDateRange}
                    </span>
                    {week.isCurrentWeek && (
                      <span className="px-1.5 py-0.2 bg-[#A3FF5F] text-[#0B0F14] text-[9px] font-black rounded-md uppercase tracking-wider">
                        Current
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-[#9AA7B5] block mt-0.5">
                    {week.sessionCount} {week.sessionCount === 1 ? 'session' : 'sessions'} recorded
                  </span>
                </div>

                {renderStatusBadge(week.reportStatus, week.report?.submittedAt)}
              </div>

              {/* Progress & Hours Bar */}
              <div className="mt-3.5">
                <div className="flex items-baseline justify-between text-xs mb-1.5">
                  <span className="font-extrabold text-base text-[#F4F7FA] font-mono-numbers">
                    {formatMinutes(week.totalMinutes)}
                    <span className="text-xs font-normal text-[#9AA7B5] ml-1">
                      / {week.goalHours}h goal
                    </span>
                  </span>
                  <span
                    className={`font-bold font-mono-numbers ${
                      week.totalMinutes >= week.goalHours * 60
                        ? 'text-[#A3FF5F]'
                        : 'text-[#9AA7B5]'
                    }`}
                  >
                    {week.progressPercent}%
                  </span>
                </div>

                <div className="w-full h-2 bg-[#0B0F14] rounded-full overflow-hidden border border-[#293441]/70">
                  <div
                    className="h-full bg-[#A3FF5F] rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.max(0, (week.totalMinutes / (week.goalHours * 60)) * 100)
                      )}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
