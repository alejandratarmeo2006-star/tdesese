import React from 'react';
import { CalendarCheck, ChevronRight, X } from 'lucide-react';

interface SundayReminderBannerProps {
  onOpenReport: () => void;
  onDismiss: () => void;
}

export const SundayReminderBanner: React.FC<SundayReminderBannerProps> = ({
  onOpenReport,
  onDismiss,
}) => {
  return (
    <div className="bg-gradient-to-r from-[#1B2530] via-[#141B23] to-[#1B2530] border-2 border-[#A3FF5F]/50 rounded-2xl p-4 shadow-[0_0_20px_rgba(163,255,95,0.15)] relative overflow-hidden">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#A3FF5F] text-[#0B0F14] flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(163,255,95,0.5)]">
            <CalendarCheck className="w-5 h-5 font-bold" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-[#A3FF5F] uppercase tracking-wider">
                Sunday Report Reminder
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#A3FF5F] animate-pulse" />
            </div>
            <h3 className="text-sm font-bold text-[#F4F7FA] mt-0.5">
              Weekly Service Report is Due Today
            </h3>
            <p className="text-xs text-[#9AA7B5] mt-1 leading-relaxed">
              Complete your four reporting metrics and submit to Microsoft Forms to close this week.
            </p>

            <button
              type="button"
              onClick={onOpenReport}
              className="mt-3 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#A3FF5F] text-[#0B0F14] text-xs font-bold hover:brightness-110 active:scale-95 transition-all shadow-md"
            >
              <span>Complete Weekly Report</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={onDismiss}
          className="w-8 h-8 rounded-lg bg-[#0B0F14]/60 text-[#9AA7B5] hover:text-[#F4F7FA] flex items-center justify-center shrink-0 transition-colors"
          aria-label="Dismiss Sunday reminder for this session"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
