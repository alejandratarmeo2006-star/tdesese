import React from 'react';
import { formatMinutes, getDaysOfWeek } from '../utils/dateUtils';
import { ServiceSession } from '../types';

interface WeeklyCalendarStripProps {
  weekStartDate: string;
  selectedDate: string;
  todayDate: string;
  sessions: ServiceSession[];
  onSelectDate: (dateStr: string) => void;
}

export const WeeklyCalendarStrip: React.FC<WeeklyCalendarStripProps> = ({
  weekStartDate,
  selectedDate,
  todayDate,
  sessions,
  onSelectDate,
}) => {
  const days = getDaysOfWeek(weekStartDate);

  // Compute total for each day
  const dailyTotals = React.useMemo(() => {
    const map = new Map<string, number>();
    for (const s of sessions) {
      const current = map.get(s.date) || 0;
      map.set(s.date, current + s.durationMinutes);
    }
    return map;
  }, [sessions]);

  return (
    <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-3.5 shadow-md">
      <div className="flex items-center justify-between mb-2.5 px-1">
        <span className="text-[11px] font-bold uppercase tracking-wider text-[#9AA7B5]">
          Monday – Sunday Overview
        </span>
        <span className="text-[11px] text-[#9AA7B5]">Tap a day to view sessions</span>
      </div>

      <div className="grid grid-cols-7 gap-1.5">
        {days.map((day) => {
          const totalMins = dailyTotals.get(day.date) || 0;
          const isSelected = day.date === selectedDate;
          const isToday = day.date === todayDate;
          const hasHours = totalMins > 0;

          return (
            <button
              key={day.date}
              type="button"
              onClick={() => onSelectDate(day.date)}
              className={`flex flex-col items-center justify-between py-2 px-1 rounded-xl transition-all duration-150 relative min-h-[72px] ${
                isSelected
                  ? 'bg-[#1B2530] border-2 border-[#A3FF5F] shadow-[0_0_12px_rgba(163,255,95,0.25)]'
                  : 'bg-[#0B0F14]/60 border border-[#293441]/70 hover:border-[#9AA7B5]/40'
              }`}
              aria-label={`${day.fullDayName}, ${day.date}: ${formatMinutes(totalMins)}`}
            >
              {/* Today marker pill */}
              {isToday && (
                <span className="absolute -top-1.5 px-1 py-0.2 bg-[#A3FF5F] text-[#0B0F14] text-[8px] font-extrabold rounded-full tracking-wider uppercase">
                  Today
                </span>
              )}

              {/* Day Name */}
              <span
                className={`text-[10px] font-bold tracking-tight uppercase ${
                  isSelected
                    ? 'text-[#A3FF5F]'
                    : isToday
                    ? 'text-[#F4F7FA]'
                    : 'text-[#9AA7B5]'
                }`}
              >
                {day.dayName}
              </span>

              {/* Day Number */}
              <span
                className={`text-sm font-extrabold font-mono-numbers my-0.5 ${
                  isSelected
                    ? 'text-white'
                    : isToday
                    ? 'text-[#A3FF5F]'
                    : 'text-[#F4F7FA]'
                }`}
              >
                {day.dayNumber}
              </span>

              {/* Served Duration */}
              <span
                className={`text-[9.5px] font-semibold font-mono-numbers tracking-tight truncate w-full text-center ${
                  hasHours
                    ? isSelected
                      ? 'text-[#A3FF5F] font-bold'
                      : 'text-[#A3FF5F]'
                    : 'text-[#9AA7B5]/50'
                }`}
              >
                {hasHours ? formatMinutes(totalMins) : '0m'}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
