import React from 'react';
import { AlertCircle, ChevronRight } from 'lucide-react';
import { WeekSummary } from '../types';

interface PendingReportNoticeProps {
  pendingWeeks: WeekSummary[];
  onOpenReport: (weekStartDate: string) => void;
}

export const PendingReportNotice: React.FC<PendingReportNoticeProps> = ({
  pendingWeeks,
  onOpenReport,
}) => {
  if (pendingWeeks.length === 0) return null;

  return (
    <div className="space-y-2">
      {pendingWeeks.map((week) => (
        <div
          key={week.weekStartDate}
          className="bg-amber-950/40 border border-amber-600/50 rounded-2xl p-3.5 flex items-center justify-between gap-3 text-amber-200"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <AlertCircle className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                Pending Past Report
              </span>
              <span className="text-xs font-semibold text-[#F4F7FA] block mt-0.5">
                Week of {week.formattedDateRange}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onOpenReport(week.weekStartDate)}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-500 text-black text-xs font-bold hover:bg-amber-400 transition-colors shrink-0"
          >
            <span>Finish Report</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
