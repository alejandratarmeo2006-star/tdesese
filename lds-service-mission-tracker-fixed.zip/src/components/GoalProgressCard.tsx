import React from 'react';
import { Award, CheckCircle2, ChevronRight, Sparkles } from 'lucide-react';
import { formatMinutes, formatWeekDateRange } from '../utils/dateUtils';

interface GoalProgressCardProps {
  weekStartDate: string;
  weekEndDate: string;
  totalMinutes: number;
  goalHours: number;
  onOpenReport?: () => void;
  reportStatus?: 'not_started' | 'in_progress' | 'pending_submission' | 'submitted';
}

export const GoalProgressCard: React.FC<GoalProgressCardProps> = ({
  weekStartDate,
  weekEndDate,
  totalMinutes,
  goalHours,
  onOpenReport,
  reportStatus,
}) => {
  const goalMinutes = goalHours * 60;
  const isGoalMet = totalMinutes >= goalMinutes;
  const progressPercent = Math.min(
    100,
    Math.round((totalMinutes / goalMinutes) * 1000) / 10
  );
  const remainingMinutes = Math.max(0, goalMinutes - totalMinutes);
  const excessMinutes = Math.max(0, totalMinutes - goalMinutes);

  const formattedRange = formatWeekDateRange(weekStartDate, weekEndDate);
  const formattedCurrent = formatMinutes(totalMinutes);
  const formattedGoal = `${goalHours}h`;

  return (
    <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-5 shadow-lg relative overflow-hidden">
      {/* Subtle background glow effect when near or at goal */}
      {isGoalMet && (
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#A3FF5F]/10 blur-2xl rounded-full pointer-events-none" />
      )}

      {/* Header Row */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div>
          <span className="text-[11px] font-bold tracking-wider text-[#9AA7B5] uppercase block">
            Weekly Service Goal
          </span>
          <span className="text-xs font-medium text-[#F4F7FA]/70 block mt-0.5">
            {formattedRange}
          </span>
        </div>

        {reportStatus && (
          <button
            type="button"
            onClick={onOpenReport}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
              reportStatus === 'submitted'
                ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60'
                : reportStatus === 'in_progress'
                ? 'bg-blue-950/80 text-blue-400 border border-blue-800/60'
                : 'bg-[#1B2530] text-[#9AA7B5] hover:text-[#F4F7FA] border border-[#293441]'
            }`}
          >
            {reportStatus === 'submitted' ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Report Submitted</span>
              </>
            ) : reportStatus === 'in_progress' ? (
              <>
                <span>Report Draft</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </>
            ) : (
              <>
                <span>Sunday Report</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        )}
      </div>

      {/* Main Metric Display */}
      <div className="flex items-baseline justify-between mt-2 mb-3">
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-extrabold text-[#F4F7FA] font-mono-numbers tracking-tight">
            {formattedCurrent}
          </span>
          <span className="text-sm font-semibold text-[#9AA7B5] font-mono-numbers">
            / {formattedGoal}
          </span>
        </div>

        <div className="text-right">
          <span
            className={`text-lg font-bold font-mono-numbers ${
              isGoalMet ? 'text-[#A3FF5F]' : 'text-[#F4F7FA]'
            }`}
          >
            {progressPercent}%
          </span>
        </div>
      </div>

      {/* Sleek Progress Bar */}
      <div className="w-full h-3 bg-[#0B0F14] rounded-full overflow-hidden p-0.5 border border-[#293441]/80">
        <div
          className={`h-full rounded-full transition-all duration-500 ease-out ${
            isGoalMet
              ? 'bg-[#A3FF5F] shadow-[0_0_12px_rgba(163,255,95,0.6)]'
              : 'bg-gradient-to-r from-[#A3FF5F]/70 to-[#A3FF5F]'
          }`}
          style={{ width: `${Math.min(100, Math.max(0, (totalMinutes / goalMinutes) * 100))}%` }}
        />
      </div>

      {/* Footer Info / Remaining or Exceeded Status */}
      <div className="mt-3.5 pt-3 border-t border-[#293441]/60 flex items-center justify-between text-xs">
        {isGoalMet ? (
          <div className="flex items-center gap-1.5 text-[#A3FF5F] font-semibold">
            <Award className="w-4 h-4 shrink-0" />
            <span>
              {excessMinutes > 0
                ? `Goal Achieved! +${formatMinutes(excessMinutes)} extra served`
                : '40-Hour Goal Completed!'}
            </span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-[#9AA7B5]">
            <Sparkles className="w-3.5 h-3.5 text-[#A3FF5F]" />
            <span>
              <strong className="text-[#F4F7FA] font-mono-numbers">
                {formatMinutes(remainingMinutes)}
              </strong>{' '}
              remaining to reach weekly goal
            </span>
          </div>
        )}

        {onOpenReport && (
          <button
            type="button"
            onClick={onOpenReport}
            className="text-xs font-medium text-[#A3FF5F] hover:underline"
          >
            Weekly Report &rarr;
          </button>
        )}
      </div>
    </div>
  );
};
