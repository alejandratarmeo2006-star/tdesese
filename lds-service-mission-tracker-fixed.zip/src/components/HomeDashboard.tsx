import React from 'react';
import { Calendar, Clock, Plus, Sparkles } from 'lucide-react';
import { useMission } from '../context/MissionContext';
import {
  formatFullDate,
  formatMinutes,
  formatWeekDateRange,
} from '../utils/dateUtils';
import { ServiceSession } from '../types';
import { GoalProgressCard } from './GoalProgressCard';
import { WeeklyCalendarStrip } from './WeeklyCalendarStrip';
import { DailySessionList } from './DailySessionList';
import { SundayReminderBanner } from './SundayReminderBanner';
import { PendingReportNotice } from './PendingReportNotice';

interface HomeDashboardProps {
  onOpenReportModal: (weekStartDate: string) => void;
  onOpenAddSessionModal: (dateStr: string) => void;
  onEditSession: (session: ServiceSession) => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onOpenReportModal,
  onOpenAddSessionModal,
  onEditSession,
}) => {
  const {
    todayDateStr,
    currentWeekStartDate,
    currentWeekEndDate,
    activeWeekStartDate,
    selectedDateStr,
    setSelectedDate,
    activeWeekSessions,
    activeWeekTotalMinutes,
    todayTotalMinutes,
    selectedDateSessions,
    activeWeekReport,
    settings,
    showSundayReminder,
    dismissSundayReminder,
    pendingPreviousWeeks,
  } = useMission();

  const formattedToday = formatFullDate(todayDateStr);
  const currentWeekDateRange = formatWeekDateRange(currentWeekStartDate, currentWeekEndDate);

  return (
    <div className="space-y-4 pb-28 animate-in fade-in">
      {/* Top Header Card */}
      <div className="flex items-center justify-between pb-1">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#A3FF5F] block">
            LDS Service Missionary
          </span>
          <h1 className="text-xl font-extrabold text-[#F4F7FA] tracking-tight">
            {formattedToday}
          </h1>
          <span className="text-xs text-[#9AA7B5] font-medium block mt-0.5">
            Reporting Period: {currentWeekDateRange}
          </span>
        </div>

        {/* Quick Log Action */}
        <button
          type="button"
          onClick={() => onOpenAddSessionModal(selectedDateStr || todayDateStr)}
          className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-[#A3FF5F] text-[#0B0F14] text-xs font-extrabold shadow-[0_0_14px_rgba(163,255,95,0.3)] hover:brightness-110 active:scale-95 transition-all shrink-0"
          aria-label="Add service hours"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Log Hours</span>
        </button>
      </div>

      {/* Sunday Reminder Banner (Shown on Sundays unless dismissed) */}
      {showSundayReminder && (
        <SundayReminderBanner
          onOpenReport={() => onOpenReportModal(currentWeekStartDate)}
          onDismiss={dismissSundayReminder}
        />
      )}

      {/* Pending Unfinished Past Reports Notice */}
      {pendingPreviousWeeks.length > 0 && (
        <PendingReportNotice
          pendingWeeks={pendingPreviousWeeks}
          onOpenReport={(weekStart) => onOpenReportModal(weekStart)}
        />
      )}

      {/* Prominent 40-Hour Weekly Goal Card */}
      <GoalProgressCard
        weekStartDate={activeWeekStartDate}
        weekEndDate={currentWeekEndDate}
        totalMinutes={activeWeekTotalMinutes}
        goalHours={settings.weeklyGoalHours}
        onOpenReport={() => onOpenReportModal(activeWeekStartDate)}
        reportStatus={
          activeWeekReport?.isSubmitted
            ? 'submitted'
            : activeWeekReport
            ? 'in_progress'
            : 'not_started'
        }
      />

      {/* Daily & Weekly Stats Quick Bar */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-3.5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#0B0F14] border border-[#293441] flex items-center justify-center text-[#A3FF5F]">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#9AA7B5] block">
              Today's Hours
            </span>
            <span className="text-lg font-extrabold text-[#F4F7FA] font-mono-numbers">
              {formatMinutes(todayTotalMinutes)}
            </span>
          </div>
        </div>

        <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-3.5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#0B0F14] border border-[#293441] flex items-center justify-center text-[#A3FF5F]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#9AA7B5] block">
              This Week's Hours
            </span>
            <span className="text-lg font-extrabold text-[#A3FF5F] font-mono-numbers">
              {formatMinutes(activeWeekTotalMinutes)}
            </span>
          </div>
        </div>
      </div>

      {/* Monday - Sunday 7-Day Overview Strip */}
      <WeeklyCalendarStrip
        weekStartDate={activeWeekStartDate}
        selectedDate={selectedDateStr}
        todayDate={todayDateStr}
        sessions={activeWeekSessions}
        onSelectDate={setSelectedDate}
      />

      {/* Selected Day's Sessions List with Add/Edit/Delete */}
      <DailySessionList
        date={selectedDateStr}
        sessions={selectedDateSessions}
        onAddSession={() => onOpenAddSessionModal(selectedDateStr)}
        onEditSession={onEditSession}
      />
    </div>
  );
};
