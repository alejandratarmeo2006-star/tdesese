import React from 'react';
import { Home, History, Settings } from 'lucide-react';

export type NavTab = 'home' | 'history' | 'settings';

interface BottomNavProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  pendingCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  pendingCount = 0,
}) => {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#141B23]/95 backdrop-blur-lg border-t border-[#293441] pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.5)]"
      aria-label="Main Navigation"
    >
      <div className="max-w-md mx-auto grid grid-cols-3 h-16 items-center px-4">
        {/* Home Tab */}
        <button
          type="button"
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-all duration-200 ${
            currentTab === 'home'
              ? 'text-[#A3FF5F] scale-105'
              : 'text-[#9AA7B5] hover:text-[#F4F7FA]'
          }`}
          aria-label="Home Dashboard"
        >
          <Home className="w-5 h-5 transition-transform" />
          <span className="text-[11px] font-semibold tracking-wide mt-1">Home</span>
          {currentTab === 'home' && (
            <span className="w-1.5 h-1.5 bg-[#A3FF5F] rounded-full mt-0.5 shadow-[0_0_8px_#A3FF5F]" />
          )}
        </button>

        {/* History Tab */}
        <button
          type="button"
          onClick={() => onTabChange('history')}
          className={`relative flex flex-col items-center justify-center min-h-[48px] py-1 transition-all duration-200 ${
            currentTab === 'history'
              ? 'text-[#A3FF5F] scale-105'
              : 'text-[#9AA7B5] hover:text-[#F4F7FA]'
          }`}
          aria-label="History and Past Weeks"
        >
          <div className="relative">
            <History className="w-5 h-5 transition-transform" />
            {pendingCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1.5 py-0.2 bg-amber-500 text-black text-[9px] font-bold rounded-full">
                {pendingCount}
              </span>
            )}
          </div>
          <span className="text-[11px] font-semibold tracking-wide mt-1">History</span>
          {currentTab === 'history' && (
            <span className="w-1.5 h-1.5 bg-[#A3FF5F] rounded-full mt-0.5 shadow-[0_0_8px_#A3FF5F]" />
          )}
        </button>

        {/* Settings Tab */}
        <button
          type="button"
          onClick={() => onTabChange('settings')}
          className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-all duration-200 ${
            currentTab === 'settings'
              ? 'text-[#A3FF5F] scale-105'
              : 'text-[#9AA7B5] hover:text-[#F4F7FA]'
          }`}
          aria-label="Settings"
        >
          <Settings className="w-5 h-5 transition-transform" />
          <span className="text-[11px] font-semibold tracking-wide mt-1">Settings</span>
          {currentTab === 'settings' && (
            <span className="w-1.5 h-1.5 bg-[#A3FF5F] rounded-full mt-0.5 shadow-[0_0_8px_#A3FF5F]" />
          )}
        </button>
      </div>
    </nav>
  );
};
