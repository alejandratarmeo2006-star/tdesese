import React, { useState, useEffect, useMemo } from 'react';
import {
  AlertTriangle,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  HeartHandshake,
  PenTool,
  Save,
  Undo2,
  X,
} from 'lucide-react';
import { OFFICIAL_FORMS_URL, WeeklyReport } from '../types';
import { formatWeekDateRange, getWeekEndDateStr, minutesToDecimalHours } from '../utils/dateUtils';
import { useMission } from '../context/MissionContext';

interface WeeklyReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  weekStartDate: string;
}

export const WeeklyReportModal: React.FC<WeeklyReportModalProps> = ({
  isOpen,
  onClose,
  weekStartDate,
}) => {
  const { reports, sessions, saveReportDraft, confirmReportSubmission } = useMission();

  // Find existing report and sessions for this week
  const weekEndDate = useMemo(() => getWeekEndDateStr(weekStartDate), [weekStartDate]);
  const formattedDateRange = useMemo(
    () => formatWeekDateRange(weekStartDate, weekEndDate),
    [weekStartDate, weekEndDate]
  );

  const existingReport = useMemo(
    () => reports.find((r) => r.weekStartDate === weekStartDate) || null,
    [reports, weekStartDate]
  );

  const weekSessions = useMemo(
    () => sessions.filter((s) => s.weekStartDate === weekStartDate),
    [sessions, weekStartDate]
  );

  const calculatedMinutes = useMemo(
    () => weekSessions.reduce((acc, curr) => acc + curr.durationMinutes, 0),
    [weekSessions]
  );
  const calculatedHours = useMemo(
    () => minutesToDecimalHours(calculatedMinutes),
    [calculatedMinutes]
  );

  // Form State
  const [gospelStudy, setGospelStudy] = useState<string>('');
  const [companionMinistering, setCompanionMinistering] = useState<string>('');
  const [journaling, setJournaling] = useState<string>('');
  const [isManualHours, setIsManualHours] = useState<boolean>(false);
  const [manualHoursVal, setManualHoursVal] = useState<string>('');

  const [activeStep, setActiveStep] = useState<'edit' | 'review'>('edit');
  const [showConfirmSubmitDialog, setShowConfirmSubmitDialog] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Load report data into state when opened or existingReport changes
  useEffect(() => {
    if (existingReport) {
      setGospelStudy(
        existingReport.gospelStudyDays !== null ? String(existingReport.gospelStudyDays) : ''
      );
      setCompanionMinistering(
        existingReport.companionMinisteringCount !== null
          ? String(existingReport.companionMinisteringCount)
          : ''
      );
      setJournaling(
        existingReport.journalingCount !== null ? String(existingReport.journalingCount) : ''
      );
      setIsManualHours(existingReport.isHoursManuallyOverridden);
      setManualHoursVal(
        existingReport.manualHours !== null ? String(existingReport.manualHours) : ''
      );

      // If already submitted, open directly to review mode
      if (existingReport.isSubmitted) {
        setActiveStep('review');
      } else {
        setActiveStep('edit');
      }
    } else {
      setGospelStudy('');
      setCompanionMinistering('');
      setJournaling('');
      setIsManualHours(false);
      setManualHoursVal('');
      setActiveStep('edit');
    }
    setErrorMessage(null);
    setStatusMessage(null);
  }, [existingReport, weekStartDate, isOpen]);

  if (!isOpen) return null;

  // Determine current effective reported hours
  const currentReportedHours = isManualHours
    ? parseFloat(manualHoursVal) || 0
    : calculatedHours;

  // Validation
  const parsedGospel = gospelStudy === '' ? null : parseInt(gospelStudy, 10);
  const parsedCompanion = companionMinistering === '' ? null : parseInt(companionMinistering, 10);
  const parsedJournaling = journaling === '' ? null : parseInt(journaling, 10);

  const isValidForReview =
    parsedGospel !== null &&
    parsedGospel >= 0 &&
    parsedGospel <= 7 &&
    parsedCompanion !== null &&
    parsedCompanion >= 0 &&
    parsedJournaling !== null &&
    parsedJournaling >= 0 &&
    (!isManualHours || (!isNaN(parseFloat(manualHoursVal)) && parseFloat(manualHoursVal) >= 0));

  // Auto-save draft handler
  const handleSaveDraft = async () => {
    try {
      setIsSaving(true);
      setErrorMessage(null);

      await saveReportDraft({
        weekStartDate,
        gospelStudyDays: parsedGospel,
        companionMinisteringCount: parsedCompanion,
        journalingCount: parsedJournaling,
        isHoursManuallyOverridden: isManualHours,
        manualHours: isManualHours ? parseFloat(manualHoursVal) || 0 : null,
        reportedHours: currentReportedHours,
      });

      setStatusMessage('Draft saved successfully');
      setTimeout(() => setStatusMessage(null), 2500);
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to save draft');
    } finally {
      setIsSaving(false);
    }
  };

  const handleProceedToReview = async () => {
    if (!isValidForReview) {
      setErrorMessage('Please answer all 4 questions with valid numbers before reviewing.');
      return;
    }
    await handleSaveDraft();
    setActiveStep('review');
  };

  const handleOpenMicrosoftForms = () => {
    // Open in new tab securely
    window.open(OFFICIAL_FORMS_URL, '_blank', 'noopener,noreferrer');
  };

  const handleConfirmSubmission = async () => {
    try {
      setIsSaving(true);
      setErrorMessage(null);

      // Make sure draft is up to date first
      await saveReportDraft({
        weekStartDate,
        gospelStudyDays: parsedGospel,
        companionMinisteringCount: parsedCompanion,
        journalingCount: parsedJournaling,
        isHoursManuallyOverridden: isManualHours,
        manualHours: isManualHours ? parseFloat(manualHoursVal) || 0 : null,
        reportedHours: currentReportedHours,
      });

      // Confirm submission
      await confirmReportSubmission(weekStartDate);
      setShowConfirmSubmitDialog(false);
      setStatusMessage('Report confirmed as submitted!');
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to confirm submission');
    } finally {
      setIsSaving(false);
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const isAlreadySubmitted = existingReport?.isSubmitted ?? false;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div
        className="w-full max-w-lg bg-[#141B23] border-t sm:border border-[#293441] rounded-t-3xl sm:rounded-2xl p-5 sm:p-6 shadow-2xl overflow-y-auto max-h-[94vh]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="report-modal-title"
      >
        {/* Mobile handle indicator */}
        <div className="w-12 h-1 bg-[#293441] rounded-full mx-auto mb-3 sm:hidden" />

        {/* Modal Top Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-[#293441]">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#A3FF5F]">
                Weekly Missionary Report
              </span>
              {isAlreadySubmitted && (
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-700/60 text-[10px] font-bold">
                  Submitted
                </span>
              )}
            </div>
            <h2 id="report-modal-title" className="text-base font-bold text-[#F4F7FA] mt-0.5">
              Week: {formattedDateRange}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-lg bg-[#1B2530] text-[#9AA7B5] hover:text-[#F4F7FA] flex items-center justify-center transition-colors"
            aria-label="Close report"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning if already submitted */}
        {isAlreadySubmitted && (
          <div className="mt-3.5 p-3 bg-amber-950/60 border border-amber-600/60 rounded-xl text-amber-200 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-amber-300">Official Report Already Confirmed</strong>
              This report was marked submitted on{' '}
              {existingReport?.submittedAt
                ? new Date(existingReport.submittedAt).toLocaleString()
                : 'a previous date'}
              . Editing values will make local records differ from your submitted Microsoft Form.
            </div>
          </div>
        )}

        {/* Success or error message */}
        {statusMessage && (
          <div className="mt-3 p-2.5 bg-emerald-950/70 border border-emerald-700/60 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{statusMessage}</span>
          </div>
        )}

        {errorMessage && (
          <div className="mt-3 p-2.5 bg-red-950/70 border border-red-700/60 rounded-xl text-red-200 text-xs">
            {errorMessage}
          </div>
        )}

        {/* Step Navigation Tabs */}
        <div className="mt-4 grid grid-cols-2 p-1 bg-[#0B0F14] rounded-xl border border-[#293441]">
          <button
            type="button"
            onClick={() => setActiveStep('edit')}
            className={`py-2 text-xs font-bold rounded-lg transition-colors ${
              activeStep === 'edit'
                ? 'bg-[#1B2530] text-[#A3FF5F] shadow-sm'
                : 'text-[#9AA7B5] hover:text-[#F4F7FA]'
            }`}
          >
            1. Report Questions
          </button>
          <button
            type="button"
            onClick={() => setActiveStep('review')}
            className={`py-2 text-xs font-bold rounded-lg transition-colors ${
              activeStep === 'review'
                ? 'bg-[#1B2530] text-[#A3FF5F] shadow-sm'
                : 'text-[#9AA7B5] hover:text-[#F4F7FA]'
            }`}
          >
            2. Review &amp; Submit
          </button>
        </div>

        {/* STEP 1: EDIT QUESTIONS */}
        {activeStep === 'edit' && (
          <div className="mt-4 space-y-4">
            {/* Metric A: Personal Gospel Study */}
            <div className="p-3.5 bg-[#1B2530]/60 border border-[#293441] rounded-xl">
              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#0B0F14] text-[#A3FF5F] flex items-center justify-center shrink-0 mt-0.5">
                  <BookOpen className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#A3FF5F] block">
                    A. Personal Gospel Study
                  </span>
                  <p className="text-xs text-[#F4F7FA] font-medium mt-1 leading-snug">
                    Enter the number of days that you had personal gospel study this week:
                  </p>
                  <p className="text-[11px] text-[#9AA7B5] mt-0.5">Expected range: 0 – 7 days</p>

                  <div className="mt-2.5 flex items-center gap-3">
                    <input
                      type="number"
                      min="0"
                      max="7"
                      step="1"
                      inputMode="numeric"
                      value={gospelStudy}
                      onChange={(e) => setGospelStudy(e.target.value)}
                      placeholder="0–7"
                      className="w-24 bg-[#0B0F14] border border-[#293441] rounded-xl px-3 py-2 text-base font-bold font-mono-numbers text-[#F4F7FA] focus:outline-none focus:border-[#A3FF5F] focus:ring-1 focus:ring-[#A3FF5F]"
                    />
                    <div className="flex gap-1">
                      {[0, 1, 2, 3, 4, 5, 6, 7].map((num) => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setGospelStudy(String(num))}
                          className={`w-7 h-7 rounded-lg text-xs font-semibold font-mono-numbers border transition-colors ${
                            gospelStudy === String(num)
                              ? 'bg-[#A3FF5F] text-[#0B0F14] border-[#A3FF5F]'
                              : 'bg-[#0B0F14] text-[#9AA7B5] border-[#293441] hover:border-[#9AA7B5]'
                          }`}
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Metric B: Companion Ministering/Study */}
            <div className="p-3.5 bg-[#1B2530]/60 border border-[#293441] rounded-xl">
              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#0B0F14] text-[#A3FF5F] flex items-center justify-center shrink-0 mt-0.5">
                  <HeartHandshake className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#A3FF5F] block">
                    B. Companion Ministering/Study
                  </span>
                  <p className="text-xs text-[#F4F7FA] font-medium mt-1 leading-snug">
                    Enter the number times you ministered to or studied with your companion this week:
                  </p>
                  <p className="text-[11px] text-[#9AA7B5] mt-0.5">Nonnegative whole number</p>

                  <div className="mt-2.5 flex items-center gap-2">
                    <input
                      type="number"
                      min="0"
                      step="1"
                      inputMode="numeric"
                      value={companionMinistering}
                      onChange={(e) => setCompanionMinistering(e.target.value)}
                      placeholder="0"
                      className="w-28 bg-[#0B0F14] border border-[#293441] rounded-xl px-3 py-2 text-base font-bold font-mono-numbers text-[#F4F7FA] focus:outline-none focus:border-[#A3FF5F] focus:ring-1 focus:ring-[#A3FF5F]"
                    />
                    <span className="text-xs text-[#9AA7B5]">times</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Metric C: Journaling and Testimony Bearing */}
            <div className="p-3.5 bg-[#1B2530]/60 border border-[#293441] rounded-xl">
              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#0B0F14] text-[#A3FF5F] flex items-center justify-center shrink-0 mt-0.5">
                  <PenTool className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#A3FF5F] block">
                    C. Journaling and Testimony Bearing
                  </span>
                  <p className="text-xs text-[#F4F7FA] font-medium mt-1 leading-snug">
                    Enter the number of times you journaled, shared a mission experience, or testified this week:
                  </p>
                  <p className="text-[11px] text-[#9AA7B5] mt-0.5">Nonnegative whole number</p>

                  <div className="mt-2.5 flex items-center gap-2">
                    <input
                      type="number"
                      min="0"
                      step="1"
                      inputMode="numeric"
                      value={journaling}
                      onChange={(e) => setJournaling(e.target.value)}
                      placeholder="0"
                      className="w-28 bg-[#0B0F14] border border-[#293441] rounded-xl px-3 py-2 text-base font-bold font-mono-numbers text-[#F4F7FA] focus:outline-none focus:border-[#A3FF5F] focus:ring-1 focus:ring-[#A3FF5F]"
                    />
                    <span className="text-xs text-[#9AA7B5]">times</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Metric D: Service Hours */}
            <div className="p-3.5 bg-[#1B2530]/60 border border-[#293441] rounded-xl">
              <div className="flex items-start gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-[#0B0F14] text-[#A3FF5F] flex items-center justify-center shrink-0 mt-0.5">
                  <Clock className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-[#A3FF5F] block">
                    D. Service Hours
                  </span>
                  <p className="text-xs text-[#F4F7FA] font-medium mt-1 leading-snug">
                    Enter the number of hours served this week:
                  </p>

                  {/* Calculated Suggestion Display */}
                  <div className="mt-2 p-2.5 bg-[#0B0F14] border border-[#293441] rounded-xl flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-[#9AA7B5] uppercase font-bold tracking-wider block">
                        Auto-calculated from logged sessions
                      </span>
                      <span className="text-sm font-extrabold text-[#A3FF5F] font-mono-numbers">
                        {calculatedHours} hours
                        <span className="text-xs font-normal text-[#9AA7B5] ml-1.5">
                          ({calculatedMinutes} mins total)
                        </span>
                      </span>
                    </div>

                    <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#F4F7FA]">
                      <input
                        type="checkbox"
                        checked={isManualHours}
                        onChange={(e) => {
                          setIsManualHours(e.target.checked);
                          if (e.target.checked && !manualHoursVal) {
                            setManualHoursVal(String(calculatedHours));
                          }
                        }}
                        className="w-4 h-4 rounded text-[#A3FF5F] bg-[#141B23] border-[#293441] focus:ring-0"
                      />
                      <span>Manual override</span>
                    </label>
                  </div>

                  {/* Manual adjustment input if toggled */}
                  {isManualHours && (
                    <div className="mt-2.5 p-2.5 bg-[#141B23] border border-amber-600/40 rounded-xl animate-in fade-in">
                      <span className="text-[11px] font-semibold text-amber-300 block mb-1">
                        Manual Reported Hours:
                      </span>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          step="0.25"
                          min="0"
                          value={manualHoursVal}
                          onChange={(e) => setManualHoursVal(e.target.value)}
                          placeholder="e.g. 35.5"
                          className="w-32 bg-[#0B0F14] border border-[#293441] rounded-xl px-3 py-2 text-base font-bold font-mono-numbers text-[#F4F7FA] focus:outline-none focus:border-[#A3FF5F]"
                        />
                        <span className="text-xs text-[#9AA7B5]">hours</span>
                        <button
                          type="button"
                          onClick={() => {
                            setManualHoursVal(String(calculatedHours));
                            setIsManualHours(false);
                          }}
                          className="text-[11px] text-[#9AA7B5] hover:text-[#F4F7FA] underline ml-auto"
                        >
                          Reset to calculated
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 flex gap-3">
              <button
                type="button"
                onClick={handleSaveDraft}
                disabled={isSaving}
                className="flex-1 min-h-[48px] rounded-xl bg-[#1B2530] border border-[#293441] text-[#F4F7FA] text-xs font-bold hover:bg-[#253241] flex items-center justify-center gap-1.5 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving...' : 'Save Draft'}</span>
              </button>

              <button
                type="button"
                onClick={handleProceedToReview}
                className="flex-1 min-h-[48px] rounded-xl bg-[#A3FF5F] text-[#0B0F14] text-xs font-extrabold hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_14px_rgba(163,255,95,0.25)]"
              >
                Continue to Review &rarr;
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: REVIEW & SUBMIT */}
        {activeStep === 'review' && (
          <div className="mt-4 space-y-4">
            <div className="bg-[#0B0F14] border border-[#293441] rounded-2xl p-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#9AA7B5] mb-3">
                Report Summary to Enter in Microsoft Forms
              </h3>

              <div className="space-y-2.5">
                {/* Metric A Row */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#141B23] border border-[#293441]">
                  <div>
                    <span className="text-[11px] text-[#9AA7B5] block">A. Gospel Study Days</span>
                    <span className="text-base font-extrabold text-[#F4F7FA] font-mono-numbers">
                      {parsedGospel ?? '—'} days
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(String(parsedGospel ?? 0), 'gospel')}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1B2530] text-[#9AA7B5] hover:text-[#A3FF5F] text-xs font-medium transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedKey === 'gospel' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>

                {/* Metric B Row */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#141B23] border border-[#293441]">
                  <div>
                    <span className="text-[11px] text-[#9AA7B5] block">
                      B. Companion Ministering/Study
                    </span>
                    <span className="text-base font-extrabold text-[#F4F7FA] font-mono-numbers">
                      {parsedCompanion ?? '—'} times
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(String(parsedCompanion ?? 0), 'companion')}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1B2530] text-[#9AA7B5] hover:text-[#A3FF5F] text-xs font-medium transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedKey === 'companion' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>

                {/* Metric C Row */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#141B23] border border-[#293441]">
                  <div>
                    <span className="text-[11px] text-[#9AA7B5] block">
                      C. Journaling &amp; Testimony
                    </span>
                    <span className="text-base font-extrabold text-[#F4F7FA] font-mono-numbers">
                      {parsedJournaling ?? '—'} times
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(String(parsedJournaling ?? 0), 'journaling')}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1B2530] text-[#9AA7B5] hover:text-[#A3FF5F] text-xs font-medium transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedKey === 'journaling' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>

                {/* Metric D Row */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#141B23] border border-[#293441]">
                  <div>
                    <span className="text-[11px] text-[#9AA7B5] block">
                      D. Total Service Hours
                      {isManualHours && (
                        <span className="text-amber-400 font-normal ml-1">
                          (adjusted from {calculatedHours}h)
                        </span>
                      )}
                    </span>
                    <span className="text-base font-extrabold text-[#A3FF5F] font-mono-numbers">
                      {currentReportedHours} hours
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(String(currentReportedHours), 'hours')}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#1B2530] text-[#9AA7B5] hover:text-[#A3FF5F] text-xs font-medium transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedKey === 'hours' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Official Link instructions */}
            <div className="p-3.5 bg-[#1B2530]/50 border border-[#293441] rounded-xl text-xs text-[#9AA7B5] space-y-2">
              <p>
                <strong>Step 1:</strong> Tap below to open your official Microsoft Forms reporting form in a new tab.
              </p>
              <p>
                <strong>Step 2:</strong> Enter the 4 values above into the form and submit it.
              </p>
              <p>
                <strong>Step 3:</strong> Return here and tap <em>Mark as Submitted</em> to record your confirmation.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                onClick={handleOpenMicrosoftForms}
                className="w-full min-h-[48px] rounded-xl bg-[#1B2530] border border-[#A3FF5F]/40 text-[#A3FF5F] text-xs font-bold hover:bg-[#253241] flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Open Microsoft Forms</span>
              </button>

              <button
                type="button"
                onClick={() => setShowConfirmSubmitDialog(true)}
                className={`w-full min-h-[48px] rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all shadow-md ${
                  isAlreadySubmitted
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60'
                    : 'bg-[#A3FF5F] text-[#0B0F14] hover:brightness-110 shadow-[0_0_16px_rgba(163,255,95,0.3)]'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {isAlreadySubmitted ? 'Re-confirm Submission' : 'Mark as Submitted'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveStep('edit')}
                className="w-full py-2.5 text-xs text-[#9AA7B5] hover:text-[#F4F7FA] flex items-center justify-center gap-1.5 transition-colors"
              >
                <Undo2 className="w-3.5 h-3.5" />
                <span>Back to Edit Report Questions</span>
              </button>
            </div>
          </div>
        )}

        {/* Confirmation Modal */}
        {showConfirmSubmitDialog && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
            <div className="w-full max-w-sm bg-[#141B23] border border-[#293441] rounded-2xl p-5 shadow-2xl">
              <div className="w-10 h-10 rounded-full bg-[#A3FF5F]/20 text-[#A3FF5F] flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-center text-[#F4F7FA]">
                Confirm Microsoft Forms Submission?
              </h4>
              <p className="mt-2 text-xs text-[#9AA7B5] text-center leading-relaxed">
                Did you complete and submit your report for{' '}
                <strong className="text-[#F4F7FA]">{formattedDateRange}</strong> on Microsoft Forms?
              </p>

              <div className="mt-5 flex gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowConfirmSubmitDialog(false)}
                  disabled={isSaving}
                  className="flex-1 py-2.5 rounded-xl bg-[#1B2530] border border-[#293441] text-xs font-semibold text-[#F4F7FA] hover:bg-[#253241]"
                >
                  Not Yet
                </button>
                <button
                  type="button"
                  onClick={handleConfirmSubmission}
                  disabled={isSaving}
                  className="flex-1 py-2.5 rounded-xl bg-[#A3FF5F] text-[#0B0F14] text-xs font-extrabold hover:brightness-110 shadow-lg"
                >
                  {isSaving ? 'Confirming...' : 'Yes, Submitted'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
