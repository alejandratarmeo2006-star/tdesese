import React, { useState } from 'react';
import {
  AlertTriangle,
  Clock,
  Download,
  ExternalLink,
  Globe,
  HardDrive,
  Info,
  Layers,
  Smartphone,
  Upload,
} from 'lucide-react';
import { OFFICIAL_FORMS_URL } from '../types';
import { getDeviceTimeZone } from '../utils/dateUtils';
import { exportAllData, importAllData } from '../services/db';
import { useMission } from '../context/MissionContext';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const SettingsView: React.FC = () => {
  const { settings, refreshAll } = useMission();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const deviceTimeZone = getDeviceTimeZone();

  // Export data handler
  const handleExportData = async () => {
    try {
      setIsExporting(true);
      const jsonStr = await exportAllData();
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `lds-mission-tracker-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: unknown) {
      console.error('Export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  // Import data handler
  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setImportStatus('Importing backup...');
      setImportError(null);
      const text = await file.text();
      const result = await importAllData(text);
      await refreshAll();
      setImportStatus(
        `Successfully restored ${result.sessionCount} sessions and ${result.reportCount} reports!`
      );
      setTimeout(() => setImportStatus(null), 5000);
    } catch (err: unknown) {
      setImportError(err instanceof Error ? err.message : 'Failed to import backup');
      setImportStatus(null);
    } finally {
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-4 pb-24 animate-in fade-in">
      {/* Title */}
      <div>
        <span className="text-[10px] font-bold uppercase tracking-wider text-[#A3FF5F] block">
          Configuration &amp; Device
        </span>
        <h2 className="text-xl font-extrabold text-[#F4F7FA]">App Settings</h2>
      </div>

      {/* Goal Specification Card */}
      <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-4">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg bg-[#A3FF5F]/10 border border-[#A3FF5F]/20 text-[#A3FF5F] flex items-center justify-center">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#F4F7FA]">Fixed Weekly Service Goal</h3>
            <span className="text-xs text-[#9AA7B5]">Default Standard Requirement</span>
          </div>
        </div>

        <div className="mt-3 p-3 bg-[#0B0F14] rounded-xl border border-[#293441] flex items-center justify-between">
          <span className="text-xs text-[#9AA7B5]">Standard Weekly Goal:</span>
          <span className="text-sm font-extrabold text-[#A3FF5F] font-mono-numbers">
            {settings.weeklyGoalHours} Hours / Week
          </span>
        </div>
        <p className="mt-2 text-[11px] text-[#9AA7B5] leading-relaxed">
          The weekly service target is fixed at 40 hours per the LDS Service Mission guidelines. Calculations track progress in exact integer minutes.
        </p>
      </div>

      {/* System Clock & Local Timezone */}
      <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-4">
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg bg-[#1B2530] text-[#A3FF5F] flex items-center justify-center">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#F4F7FA]">Device System Clock &amp; Calendar</h3>
            <span className="text-xs text-[#9AA7B5]">Timezone &amp; Rollover Engine</span>
          </div>
        </div>

        <div className="space-y-2 mt-3">
          <div className="p-3 bg-[#0B0F14] rounded-xl border border-[#293441] flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-[#9AA7B5]">
              <Globe className="w-3.5 h-3.5 text-[#9AA7B5]" />
              <span>Current Timezone:</span>
            </div>
            <span className="text-xs font-bold text-[#F4F7FA] font-mono-numbers">
              {deviceTimeZone}
            </span>
          </div>
        </div>

        <p className="mt-2.5 text-[11px] text-[#9AA7B5] leading-relaxed">
          All service dates and reporting weeks strictly follow your device's local calendar and system time zone. Monday automatically begins each new reporting cycle, and historical sessions never shift across date boundaries.
        </p>
      </div>

      {/* Official Microsoft Forms Link */}
      <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#F4F7FA]">Official Microsoft Forms</h3>
            <span className="text-xs text-[#9AA7B5] block mt-0.5">
              Service Missionary Weekly Report Link
            </span>
          </div>
          <a
            href={OFFICIAL_FORMS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1B2530] border border-[#293441] hover:border-[#A3FF5F]/50 text-[#A3FF5F] text-xs font-bold transition-colors"
          >
            <span>Open Link</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Local Storage & Device Persistence Notice */}
      <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-4">
        <div className="flex items-start gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
            <HardDrive className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#F4F7FA]">Local Device Storage Notice</h3>
            <p className="mt-1.5 text-xs text-[#9AA7B5] leading-relaxed">
              Your service sessions and reports are stored securely and locally on this device via IndexedDB. There are no cloud accounts or remote servers.
            </p>
            <p className="mt-2 text-xs text-amber-200/90 leading-relaxed font-medium">
              Important: Clearing browser site data, clearing browser cache, or uninstalling your browser will permanently delete these local records. Use the backup option below to keep a copy of your hours.
            </p>
          </div>
        </div>

        {/* Backup & Restore Controls */}
        <div className="mt-4 pt-3 border-t border-[#293441] space-y-2.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#9AA7B5] block">
            Data Backup &amp; Transfer
          </span>

          {importStatus && (
            <div className="p-2.5 bg-emerald-950/70 border border-emerald-700/60 rounded-xl text-emerald-200 text-xs">
              {importStatus}
            </div>
          )}

          {importError && (
            <div className="p-2.5 bg-red-950/70 border border-red-700/60 rounded-xl text-red-200 text-xs">
              {importError}
            </div>
          )}

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={handleExportData}
              disabled={isExporting}
              className="min-h-[44px] rounded-xl bg-[#1B2530] border border-[#293441] hover:border-[#A3FF5F]/50 text-[#F4F7FA] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#A3FF5F]" />
              <span>{isExporting ? 'Exporting...' : 'Export Backup'}</span>
            </button>

            <label className="min-h-[44px] rounded-xl bg-[#1B2530] border border-[#293441] hover:border-[#A3FF5F]/50 text-[#F4F7FA] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer">
              <Upload className="w-3.5 h-3.5 text-[#A3FF5F]" />
              <span>Restore Backup</span>
              <input
                type="file"
                accept=".json,application/json"
                onChange={handleImportFile}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* PWA / Android Installation Guidance */}
      <div className="bg-[#141B23] border border-[#293441] rounded-2xl p-4">
        <div className="flex items-start gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#1B2530] text-[#A3FF5F] flex items-center justify-center shrink-0">
            <Smartphone className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-bold text-[#F4F7FA]">Android Phone Home Screen App</h3>
            <p className="mt-1 text-xs text-[#9AA7B5] leading-relaxed">
              This app is built as a standalone web app for Android. To install it directly on your phone's home screen without an app store:
            </p>

            {isInstallable && (
              <button
                type="button"
                onClick={install}
                className="mt-3 w-full min-h-[44px] rounded-xl bg-[#A3FF5F] text-[#0B0F14] text-xs font-extrabold flex items-center justify-center gap-2 hover:brightness-110 shadow-md transition-all"
              >
                <Smartphone className="w-4 h-4" />
                <span>Install on Phone</span>
              </button>
            )}

            {isInstalled && (
              <div className="mt-3 p-2 bg-emerald-950/60 border border-emerald-800/60 rounded-xl text-emerald-300 text-xs font-semibold text-center">
                ✓ Running in Standalone Installed App Mode
              </div>
            )}

            {!isInstallable && !isInstalled && (
              <div className="mt-3 p-3 bg-[#0B0F14] rounded-xl border border-[#293441] text-xs text-[#9AA7B5] space-y-1">
                <p className="font-semibold text-[#F4F7FA]">On Android (Chrome / Samsung Internet):</p>
                <p>1. Tap the browser menu (three dots in top or bottom right corner).</p>
                <p>2. Tap <strong>Install App</strong> or <strong>Add to Home screen</strong>.</p>
                <p className="mt-2 font-semibold text-[#F4F7FA]">On iPhone (Safari):</p>
                <p>1. Tap the Share icon (square with arrow up).</p>
                <p>2. Scroll down and tap <strong>Add to Home Screen</strong>.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
