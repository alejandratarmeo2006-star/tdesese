/**
 * LDS Service Mission Tracker — Dark Edition
 * Mobile-first application for tracking daily service hours, 40-hour weekly goals,
 * and completing weekly official missionary reports for Microsoft Forms submission.
 */

import React, { useState } from 'react';
import { MissionProvider, useMission } from './context/MissionContext';
import { BottomNav, NavTab } from './components/BottomNav';
import { HomeDashboard } from './components/HomeDashboard';
import { HistoryView } from './components/HistoryView';
import { SettingsView } from './components/SettingsView';
import { SessionModal } from './components/SessionModal';
import { WeeklyReportModal } from './components/WeeklyReportModal';
import { ServiceSession } from './types';
import { Shield, Sparkles } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const {
    isLoading,
    error,
    currentWeekStartDate,
    todayDateStr,
    pendingPreviousWeeks,
  } = useMission();

  const [currentTab, setCurrentTab] = useState<NavTab>('home');

  // Session Modal State
  const [isSessionModalOpen, setIsSessionModalOpen] = useState<boolean>(false);
  const [sessionToEdit, setSessionToEdit] = useState<ServiceSession | null>(null);
  const [sessionModalDate, setSessionModalDate] = useState<string>(todayDateStr);

  // Report Modal State
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [reportWeekStartDate, setReportWeekStartDate] = useState<string>(currentWeekStartDate);

  // Modal handlers
  const handleOpenAddSession = (dateStr?: string) => {
    setSessionToEdit(null);
    setSessionModalDate(dateStr || todayDateStr);
    setIsSessionModalOpen(true);
  };

  const handleOpenEditSession = (session: ServiceSession) => {
    setSessionToEdit(session);
    setSessionModalDate(session.date);
    setIsSessionModalOpen(true);
  };

  const handleOpenReport = (weekStartDate: string) => {
    setReportWeekStartDate(weekStartDate);
    setIsReportModalOpen(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0B0F14] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-12 h-12 rounded-2xl bg-[#141B23] border border-[#293441] flex items-center justify-center text-[#A3FF5F] animate-pulse shadow-[0_0_20px_rgba(163,255,95,0.2)] mb-4">
          <Shield className="w-6 h-6" />
        </div>
        <h2 className="text-sm font-bold text-[#F4F7FA] tracking-wide">
          Loading Service Records...
        </h2>
        <p className="text-xs text-[#9AA7B5] mt-1">Connecting to local device storage</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0F14] text-[#F4F7FA] selection:bg-[#A3FF5F]/30 selection:text-white flex flex-col">
      {/* Top App Bar */}
      <header className="sticky top-0 z-30 bg-[#0B0F14]/90 backdrop-blur-md border-b border-[#293441]/80 px-4 py-3">
        <div className="max-w-xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#141B23] border border-[#293441] flex items-center justify-center text-[#A3FF5F] shadow-sm">
              <Shield className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <span className="text-sm font-extrabold tracking-tight text-[#F4F7FA] block leading-none">
                Service Mission Tracker
              </span>
              <span className="text-[10px] font-semibold text-[#A3FF5F] tracking-wide uppercase">
                Dark Edition
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-medium text-[#9AA7B5] hidden sm:inline">
              Goal: 40h/wk
            </span>
            <div className="px-2 py-0.5 rounded-full bg-[#141B23] border border-[#293441] text-[10px] font-mono-numbers text-[#9AA7B5]">
              Local Storage
            </div>
          </div>
        </div>
      </header>

      {/* Global Error Banner if any */}
      {error && (
        <div className="max-w-xl mx-auto w-full px-4 pt-3">
          <div className="p-3 bg-red-950/80 border border-red-700/60 rounded-xl text-red-200 text-xs">
            <strong>Storage Warning:</strong> {error}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-xl mx-auto w-full px-4 pt-4">
        {currentTab === 'home' && (
          <HomeDashboard
            onOpenReportModal={handleOpenReport}
            onOpenAddSessionModal={handleOpenAddSession}
            onEditSession={handleOpenEditSession}
          />
        )}

        {currentTab === 'history' && (
          <HistoryView
            onOpenReportForWeek={handleOpenReport}
            onAddSessionForDate={handleOpenAddSession}
            onEditSession={handleOpenEditSession}
          />
        )}

        {currentTab === 'settings' && <SettingsView />}
      </main>

      {/* Fixed Bottom Navigation */}
      <BottomNav
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        pendingCount={pendingPreviousWeeks.length}
      />

      {/* Add / Edit Session Modal */}
      <SessionModal
        isOpen={isSessionModalOpen}
        onClose={() => {
          setIsSessionModalOpen(false);
          setSessionToEdit(null);
        }}
        sessionToEdit={sessionToEdit}
        defaultDate={sessionModalDate}
      />

      {/* Weekly Report Modal */}
      <WeeklyReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        weekStartDate={reportWeekStartDate}
      />
    </div>
  );
};

export default function App() {
  return (
    <MissionProvider>
      <MainAppContent />
    </MissionProvider>
  );
}
